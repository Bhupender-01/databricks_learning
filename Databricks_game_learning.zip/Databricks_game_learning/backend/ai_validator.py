"""
AI-powered code validation engine for Databricks Learning Platform.
Provides instant feedback and personalized hints.
"""
import json
import re
from typing import List, Dict, Tuple
import time

class AICodeValidator:
    """
    Validates user code submissions against expected solutions.
    Provides detailed feedback and hints for improvement.
    """
    
    def __init__(self):
        self.sql_keywords = ['SELECT', 'FROM', 'WHERE', 'JOIN', 'GROUP BY', 'ORDER BY', 
                            'HAVING', 'WITH', 'INSERT', 'UPDATE', 'DELETE', 'CREATE',
                            'ALTER', 'DROP', 'UNION', 'EXCEPT', 'INTERSECT']
        self.pyspark_keywords = ['spark', 'DataFrame', 'filter', 'select', 'groupBy',
                                'agg', 'join', 'withColumn', 'col', 'when', 'window']
        self.delta_keywords = ['delta', 'DeltaTable', 'merge', 'vacuum', 'optimize',
                              'ZORDER', 'history', 'versionAsOf', 'timestampAsOf']
    
    def validate_code(self, user_code: str, challenge: dict) -> Dict:
        """
        Main validation method that checks user code against challenge requirements.
        
        Args:
            user_code: The code submitted by the user
            challenge: Challenge object with solution, test_cases, hints
            
        Returns:
            Dictionary with validation results, score, feedback, and hints
        """
        start_time = time.time()
        
        # Clean up code
        user_code_clean = self._clean_code(user_code)
        
        # Parse test cases
        test_cases = json.loads(challenge.get('test_cases', '[]'))
        
        # Run validation checks
        syntax_result = self._check_syntax(user_code_clean, challenge['category'])
        test_results = self._run_test_cases(user_code_clean, test_cases)
        logic_result = self._check_logic(user_code_clean, challenge)
        
        # Calculate score (0-100)
        syntax_score = 30 if syntax_result['valid'] else 0
        test_score = 50 * (test_results['passed'] / max(test_results['total'], 1))
        logic_score = 20 if logic_result['valid'] else 0
        total_score = int(syntax_score + test_score + logic_score)
        
        # Determine if correct (need at least 80%)
        is_correct = total_score >= 80
        
        # Generate feedback
        feedback = self._generate_feedback(
            syntax_result, test_results, logic_result, 
            challenge['category'], is_correct
        )
        
        # Get hints based on errors
        hints = self._generate_hints(
            user_code_clean, challenge, 
            syntax_result, test_results, logic_result
        )
        
        execution_time = time.time() - start_time
        
        return {
            'is_correct': is_correct,
            'score': total_score,
            'feedback': feedback,
            'hints': hints,
            'execution_time': round(execution_time, 3),
            'details': {
                'syntax': syntax_result,
                'tests': test_results,
                'logic': logic_result
            }
        }
    
    def _clean_code(self, code: str) -> str:
        """Remove comments and extra whitespace."""
        # Remove single-line comments
        code = re.sub(r'--.*$', '', code, flags=re.MULTILINE)
        code = re.sub(r'#.*$', '', code, flags=re.MULTILINE)
        # Remove multi-line comments
        code = re.sub(r'/\*.*?\*/', '', code, flags=re.DOTALL)
        code = re.sub(r'""".*?"""', '', code, flags=re.DOTALL)
        code = re.sub(r"'''.*?'''", '', code, flags=re.DOTALL)
        # Normalize whitespace
        code = ' '.join(code.split())
        return code.strip()
    
    def _check_syntax(self, code: str, category: str) -> Dict:
        """Check for basic syntax validity."""
        errors = []
        warnings = []
        
        if not code:
            return {'valid': False, 'errors': ['No code provided'], 'warnings': []}
        
        # Check for balanced parentheses
        if code.count('(') != code.count(')'):
            errors.append('Unbalanced parentheses')
        
        # Check for balanced brackets
        if code.count('[') != code.count(']'):
            errors.append('Unbalanced brackets')
        
        # Check for balanced braces
        if code.count('{') != code.count('}'):
            errors.append('Unbalanced braces')
        
        # Check for unclosed strings
        single_quotes = code.count("'") - code.count("\\'")
        double_quotes = code.count('"') - code.count('\\"')
        if single_quotes % 2 != 0:
            errors.append('Unclosed single quote string')
        if double_quotes % 2 != 0:
            errors.append('Unclosed double quote string')
        
        # Category-specific checks
        if category == 'SQL':
            if not any(kw in code.upper() for kw in ['SELECT', 'INSERT', 'UPDATE', 'DELETE', 'CREATE', 'WITH']):
                warnings.append('Missing SQL statement keyword')
        elif category == 'PySpark':
            if 'spark' not in code.lower() and 'df' not in code.lower():
                warnings.append('Missing Spark/DataFrame reference')
        elif category == 'Delta Lake':
            if 'delta' not in code.lower() and 'DeltaTable' not in code:
                warnings.append('Missing Delta Lake reference')
        
        return {
            'valid': len(errors) == 0,
            'errors': errors,
            'warnings': warnings
        }
    
    def _run_test_cases(self, code: str, test_cases: List[Dict]) -> Dict:
        """Run test cases against the code."""
        passed = 0
        failed = []
        
        for i, test in enumerate(test_cases):
            check_type = test.get('check', 'contains')
            value = test.get('value', '')
            
            if check_type == 'contains':
                if value.upper() in code.upper():
                    passed += 1
                else:
                    failed.append(f"Missing: {value}")
            elif check_type == 'not_contains':
                if value.upper() not in code.upper():
                    passed += 1
                else:
                    failed.append(f"Should not contain: {value}")
            elif check_type == 'regex':
                if re.search(value, code, re.IGNORECASE):
                    passed += 1
                else:
                    failed.append(f"Pattern not found")
            elif check_type == 'exact':
                if code.strip().upper() == value.strip().upper():
                    passed += 1
                else:
                    failed.append("Exact match required")
        
        return {
            'total': len(test_cases),
            'passed': passed,
            'failed': failed
        }
    
    def _check_logic(self, code: str, challenge: dict) -> Dict:
        """Check logical correctness of the code."""
        solution = self._clean_code(challenge.get('solution_code', ''))
        
        # Extract key elements from solution
        solution_upper = solution.upper()
        code_upper = code.upper()
        
        # Check for key structural elements
        key_elements = []
        missing_elements = []
        
        # Extract function calls and keywords from solution
        solution_keywords = set(re.findall(r'\b([A-Z_]{2,})\b', solution_upper))
        code_keywords = set(re.findall(r'\b([A-Z_]{2,})\b', code_upper))
        
        # Check for important missing keywords
        important_keywords = solution_keywords - code_keywords
        # Filter out common words
        common_words = {'THE', 'AND', 'OR', 'NOT', 'IF', 'ELSE', 'TRUE', 'FALSE', 'NULL', 'AS', 'BY', 'IN', 'ON', 'IS'}
        important_keywords = important_keywords - common_words
        
        if len(important_keywords) > 3:
            missing_elements = list(important_keywords)[:3]
        
        # Calculate similarity score
        overlap = len(solution_keywords & code_keywords)
        total = len(solution_keywords)
        similarity = overlap / max(total, 1)
        
        return {
            'valid': similarity >= 0.6,
            'similarity': round(similarity * 100, 1),
            'missing_elements': missing_elements
        }
    
    def _generate_feedback(self, syntax: Dict, tests: Dict, logic: Dict, 
                          category: str, is_correct: bool) -> str:
        """Generate human-readable feedback."""
        feedback_parts = []
        
        if is_correct:
            feedback_parts.append("🎉 **Excellent work!** Your solution is correct!")
            if logic['similarity'] == 100:
                feedback_parts.append("Your code perfectly matches the expected solution.")
            elif logic['similarity'] >= 80:
                feedback_parts.append("Your approach is very close to the optimal solution.")
        else:
            feedback_parts.append("❌ **Not quite right.** Let's see what can be improved:")
            
            if syntax['errors']:
                feedback_parts.append(f"\n**Syntax Issues:**")
                for error in syntax['errors']:
                    feedback_parts.append(f"  • {error}")
            
            if syntax['warnings']:
                feedback_parts.append(f"\n**Warnings:**")
                for warning in syntax['warnings']:
                    feedback_parts.append(f"  • {warning}")
            
            if tests['failed']:
                feedback_parts.append(f"\n**Test Results:** {tests['passed']}/{tests['total']} passed")
            
            if logic['missing_elements']:
                feedback_parts.append(f"\n**Consider using:** {', '.join(logic['missing_elements'])}")
        
        return '\n'.join(feedback_parts)
    
    def _generate_hints(self, code: str, challenge: dict, 
                       syntax: Dict, tests: Dict, logic: Dict) -> List[str]:
        """Generate personalized hints based on errors."""
        hints = []
        challenge_hints = json.loads(challenge.get('hints', '[]'))
        
        # If syntax errors, give first hint
        if syntax['errors'] and challenge_hints:
            hints.append(challenge_hints[0])
        
        # If tests failing, give relevant hints
        if tests['passed'] < tests['total'] and len(challenge_hints) > 1:
            hints.append(challenge_hints[1])
        
        # If logic issues and more hints available
        if not logic['valid'] and len(challenge_hints) > 2:
            hints.append(challenge_hints[2])
        
        # If close but not quite
        if logic['similarity'] >= 60 and logic['similarity'] < 80:
            hints.append("You're very close! Review your syntax and make sure all required elements are present.")
        
        # Category-specific hints
        if not hints:
            if challenge['category'] == 'SQL':
                hints.append("Make sure your SQL follows the standard syntax: SELECT ... FROM ... WHERE ...")
            elif challenge['category'] == 'PySpark':
                hints.append("Remember to chain DataFrame transformations: df.filter(...).select(...)")
            elif challenge['category'] == 'Delta Lake':
                hints.append("Delta operations often require importing from delta.tables")
        
        return hints[:3]  # Max 3 hints


# Global validator instance
validator = AICodeValidator()

def validate_submission(user_code: str, challenge: dict) -> Dict:
    """Convenience function to validate a submission."""
    return validator.validate_code(user_code, challenge)
