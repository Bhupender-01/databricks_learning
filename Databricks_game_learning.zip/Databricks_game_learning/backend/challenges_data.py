"""
Pre-defined Databricks challenges for SQL, PySpark, and Delta Lake.
"""
import json

CHALLENGES = [
    # ============== SQL CHALLENGES - BEGINNER ==============
    {
        "title": "Hello Databricks SQL",
        "description": "Welcome to Databricks SQL! Your first task is simple: write a SELECT statement that returns the string 'Hello, Databricks!' as a column named 'greeting'.",
        "category": "SQL",
        "difficulty": "beginner",
        "points": 10,
        "order_index": 1,
        "starter_code": "-- Write your SQL query here\nSELECT ",
        "solution_code": "SELECT 'Hello, Databricks!' AS greeting",
        "expected_output": "Hello, Databricks!",
        "hints": json.dumps([
            "Use single quotes for string literals in SQL",
            "Use the AS keyword to give your column a name",
            "The complete syntax is: SELECT 'value' AS column_name"
        ]),
        "test_cases": json.dumps([
            {"check": "contains", "value": "SELECT"},
            {"check": "contains", "value": "greeting"}
        ])
    },
    {
        "title": "Basic SELECT with WHERE",
        "description": "Query the 'employees' table and select all columns for employees whose department is 'Engineering'. The table has columns: id, name, department, salary.",
        "category": "SQL",
        "difficulty": "beginner",
        "points": 15,
        "order_index": 2,
        "starter_code": "-- Select all engineering employees\n-- Table: employees (id, name, department, salary)\n\nSELECT ",
        "solution_code": "SELECT * FROM employees WHERE department = 'Engineering'",
        "expected_output": None,
        "hints": json.dumps([
            "Use SELECT * to select all columns",
            "Use WHERE clause to filter rows",
            "String values need to be in single quotes"
        ]),
        "test_cases": json.dumps([
            {"check": "contains", "value": "SELECT"},
            {"check": "contains", "value": "FROM employees"},
            {"check": "contains", "value": "WHERE"},
            {"check": "contains", "value": "Engineering"}
        ])
    },
    {
        "title": "Aggregate Functions",
        "description": "Calculate the average salary from the 'employees' table and name the result column 'avg_salary'. Round the result to 2 decimal places.",
        "category": "SQL",
        "difficulty": "beginner",
        "points": 20,
        "order_index": 3,
        "starter_code": "-- Calculate average salary rounded to 2 decimals\n-- Table: employees (id, name, department, salary)\n\n",
        "solution_code": "SELECT ROUND(AVG(salary), 2) AS avg_salary FROM employees",
        "expected_output": None,
        "hints": json.dumps([
            "Use AVG() function to calculate average",
            "Use ROUND(value, decimals) to round numbers",
            "Combine them: ROUND(AVG(column), 2)"
        ]),
        "test_cases": json.dumps([
            {"check": "contains", "value": "AVG"},
            {"check": "contains", "value": "ROUND"},
            {"check": "contains", "value": "avg_salary"}
        ])
    },
    
    # ============== SQL CHALLENGES - INTERMEDIATE ==============
    {
        "title": "GROUP BY with HAVING",
        "description": "Find all departments from the 'employees' table that have more than 5 employees. Show the department name and employee count, ordered by count descending.",
        "category": "SQL",
        "difficulty": "intermediate",
        "points": 30,
        "order_index": 4,
        "starter_code": "-- Find departments with more than 5 employees\n-- Table: employees (id, name, department, salary)\n\n",
        "solution_code": "SELECT department, COUNT(*) AS employee_count\nFROM employees\nGROUP BY department\nHAVING COUNT(*) > 5\nORDER BY employee_count DESC",
        "expected_output": None,
        "hints": json.dumps([
            "Use GROUP BY to group rows by department",
            "Use COUNT(*) to count rows in each group",
            "HAVING is like WHERE but for grouped results",
            "ORDER BY with DESC for descending order"
        ]),
        "test_cases": json.dumps([
            {"check": "contains", "value": "GROUP BY"},
            {"check": "contains", "value": "HAVING"},
            {"check": "contains", "value": "COUNT"},
            {"check": "contains", "value": "ORDER BY"}
        ])
    },
    {
        "title": "JOIN Operations",
        "description": "Write a query to join 'employees' and 'departments' tables. Show employee name, their department name, and department budget. Use appropriate JOIN.",
        "category": "SQL",
        "difficulty": "intermediate",
        "points": 35,
        "order_index": 5,
        "starter_code": "-- Join employees with departments\n-- employees (id, name, dept_id, salary)\n-- departments (id, name, budget)\n\n",
        "solution_code": "SELECT e.name AS employee_name, d.name AS department_name, d.budget\nFROM employees e\nINNER JOIN departments d ON e.dept_id = d.id",
        "expected_output": None,
        "hints": json.dumps([
            "Use INNER JOIN to connect tables",
            "ON clause specifies the join condition",
            "Use table aliases (e, d) for cleaner code",
            "Select specific columns with alias.column"
        ]),
        "test_cases": json.dumps([
            {"check": "contains", "value": "JOIN"},
            {"check": "contains", "value": "ON"},
            {"check": "regex", "value": "e\\.name|employees\\.name"}
        ])
    },
    {
        "title": "Window Functions - ROW_NUMBER",
        "description": "Rank employees within each department by salary (highest first). Use ROW_NUMBER() window function. Show name, department, salary, and rank.",
        "category": "SQL",
        "difficulty": "intermediate",
        "points": 40,
        "order_index": 6,
        "starter_code": "-- Rank employees by salary within each department\n-- Table: employees (id, name, department, salary)\n\n",
        "solution_code": "SELECT \n    name,\n    department,\n    salary,\n    ROW_NUMBER() OVER (PARTITION BY department ORDER BY salary DESC) AS salary_rank\nFROM employees",
        "expected_output": None,
        "hints": json.dumps([
            "ROW_NUMBER() assigns a unique number to each row",
            "OVER() defines the window for the function",
            "PARTITION BY groups the window by a column",
            "ORDER BY within OVER() determines the ranking order"
        ]),
        "test_cases": json.dumps([
            {"check": "contains", "value": "ROW_NUMBER"},
            {"check": "contains", "value": "OVER"},
            {"check": "contains", "value": "PARTITION BY"},
            {"check": "contains", "value": "ORDER BY"}
        ])
    },
    
    # ============== SQL CHALLENGES - ADVANCED ==============
    {
        "title": "Complex CTE Query",
        "description": "Using CTEs, find the top 3 highest-paid employees in each department. Include their name, department, salary, and rank.",
        "category": "SQL",
        "difficulty": "advanced",
        "points": 50,
        "order_index": 7,
        "starter_code": "-- Use CTE to find top 3 paid employees per department\n-- Table: employees (id, name, department, salary)\n\n",
        "solution_code": """WITH ranked_employees AS (
    SELECT 
        name,
        department,
        salary,
        ROW_NUMBER() OVER (PARTITION BY department ORDER BY salary DESC) AS rank
    FROM employees
)
SELECT name, department, salary, rank
FROM ranked_employees
WHERE rank <= 3
ORDER BY department, rank""",
        "expected_output": None,
        "hints": json.dumps([
            "CTEs start with WITH keyword",
            "Define the CTE, then use it in main query",
            "Use window function inside CTE for ranking",
            "Filter by rank in the outer query"
        ]),
        "test_cases": json.dumps([
            {"check": "contains", "value": "WITH"},
            {"check": "contains", "value": "ROW_NUMBER"},
            {"check": "contains", "value": "PARTITION BY"},
            {"check": "regex", "value": "rank\\s*<=\\s*3|rank\\s*<\\s*4"}
        ])
    },
    
    # ============== PYSPARK CHALLENGES - BEGINNER ==============
    {
        "title": "Create DataFrame",
        "description": "Create a PySpark DataFrame from a list of tuples containing employee data (name, age, department). Define the schema explicitly.",
        "category": "PySpark",
        "difficulty": "beginner",
        "points": 15,
        "order_index": 10,
        "starter_code": """from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, IntegerType

# Create SparkSession (already available as 'spark')

# Sample data
data = [
    ("Alice", 30, "Engineering"),
    ("Bob", 25, "Marketing"),
    ("Charlie", 35, "Engineering")
]

# Define schema and create DataFrame
# Your code here:
""",
        "solution_code": """from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, IntegerType

data = [
    ("Alice", 30, "Engineering"),
    ("Bob", 25, "Marketing"),
    ("Charlie", 35, "Engineering")
]

schema = StructType([
    StructField("name", StringType(), True),
    StructField("age", IntegerType(), True),
    StructField("department", StringType(), True)
])

df = spark.createDataFrame(data, schema)
df.show()""",
        "expected_output": None,
        "hints": json.dumps([
            "StructType is used to define DataFrame schema",
            "StructField defines each column (name, type, nullable)",
            "Use spark.createDataFrame(data, schema)",
            "StringType() for text, IntegerType() for numbers"
        ]),
        "test_cases": json.dumps([
            {"check": "contains", "value": "StructType"},
            {"check": "contains", "value": "StructField"},
            {"check": "contains", "value": "createDataFrame"}
        ])
    },
    {
        "title": "DataFrame Transformations",
        "description": "Given a DataFrame 'df' with columns (name, age, salary), filter employees older than 25 and add a new column 'bonus' that is 10% of salary.",
        "category": "PySpark",
        "difficulty": "beginner",
        "points": 20,
        "order_index": 11,
        "starter_code": """from pyspark.sql.functions import col

# Assume df is already created with columns: name, age, salary
# Filter age > 25 and add bonus column (10% of salary)

result = df
# Your transformations here:
""",
        "solution_code": """from pyspark.sql.functions import col

result = df.filter(col("age") > 25).withColumn("bonus", col("salary") * 0.10)
result.show()""",
        "expected_output": None,
        "hints": json.dumps([
            "Use .filter() or .where() to filter rows",
            "col('column_name') references a column",
            "withColumn() adds or replaces a column",
            "Chain transformations: df.filter().withColumn()"
        ]),
        "test_cases": json.dumps([
            {"check": "contains", "value": "filter"},
            {"check": "contains", "value": "withColumn"},
            {"check": "contains", "value": "bonus"}
        ])
    },
    
    # ============== PYSPARK CHALLENGES - INTERMEDIATE ==============
    {
        "title": "GroupBy Aggregations",
        "description": "Group the 'sales' DataFrame by 'region' and 'product', then calculate: total_sales (sum), avg_price (average), and transaction_count (count).",
        "category": "PySpark",
        "difficulty": "intermediate",
        "points": 35,
        "order_index": 12,
        "starter_code": """from pyspark.sql.functions import sum, avg, count

# DataFrame 'sales' has columns: region, product, price, quantity
# Group by region and product, calculate aggregations

result = sales
# Your code here:
""",
        "solution_code": """from pyspark.sql.functions import sum, avg, count, col

result = sales.groupBy("region", "product").agg(
    sum(col("price") * col("quantity")).alias("total_sales"),
    avg("price").alias("avg_price"),
    count("*").alias("transaction_count")
)
result.show()""",
        "expected_output": None,
        "hints": json.dumps([
            "Use groupBy() with column names",
            "agg() allows multiple aggregations",
            "Use .alias() to name result columns",
            "sum, avg, count are from pyspark.sql.functions"
        ]),
        "test_cases": json.dumps([
            {"check": "contains", "value": "groupBy"},
            {"check": "contains", "value": "agg"},
            {"check": "contains", "value": "sum"},
            {"check": "contains", "value": "alias"}
        ])
    },
    {
        "title": "DataFrame Joins",
        "description": "Join 'orders' DataFrame with 'customers' DataFrame on customer_id. Perform a LEFT join and select relevant columns.",
        "category": "PySpark",
        "difficulty": "intermediate",
        "points": 40,
        "order_index": 13,
        "starter_code": """# orders: order_id, customer_id, amount, order_date
# customers: customer_id, name, email, country

# Perform LEFT join and select: order_id, customer name, amount, country
result = orders
# Your code here:
""",
        "solution_code": """result = orders.join(
    customers,
    orders.customer_id == customers.customer_id,
    "left"
).select(
    orders.order_id,
    customers.name.alias("customer_name"),
    orders.amount,
    customers.country
)
result.show()""",
        "expected_output": None,
        "hints": json.dumps([
            "Use .join(other_df, condition, join_type)",
            "Join types: 'inner', 'left', 'right', 'outer'",
            "Reference columns with df.column_name",
            "Use .select() to choose specific columns"
        ]),
        "test_cases": json.dumps([
            {"check": "contains", "value": "join"},
            {"check": "contains", "value": "left"},
            {"check": "contains", "value": "select"}
        ])
    },
    
    # ============== PYSPARK CHALLENGES - ADVANCED ==============
    {
        "title": "Window Functions in PySpark",
        "description": "Calculate a 7-day moving average of sales for each product. Use Window functions with proper partitioning and ordering.",
        "category": "PySpark",
        "difficulty": "advanced",
        "points": 50,
        "order_index": 14,
        "starter_code": """from pyspark.sql.window import Window
from pyspark.sql.functions import avg, col

# sales_df: product_id, sale_date, amount
# Calculate 7-day moving average partitioned by product

result = sales_df
# Your code here:
""",
        "solution_code": """from pyspark.sql.window import Window
from pyspark.sql.functions import avg, col

window_spec = Window.partitionBy("product_id").orderBy("sale_date").rowsBetween(-6, 0)

result = sales_df.withColumn(
    "moving_avg_7day",
    avg("amount").over(window_spec)
)
result.show()""",
        "expected_output": None,
        "hints": json.dumps([
            "Window.partitionBy() groups data for window calc",
            "orderBy() defines the order within each partition",
            "rowsBetween(-6, 0) defines a 7-row window (current + 6 previous)",
            "Apply with: function().over(window_spec)"
        ]),
        "test_cases": json.dumps([
            {"check": "contains", "value": "Window"},
            {"check": "contains", "value": "partitionBy"},
            {"check": "contains", "value": "rowsBetween"},
            {"check": "contains", "value": "over"}
        ])
    },
    
    # ============== DELTA LAKE CHALLENGES - BEGINNER ==============
    {
        "title": "Create Delta Table",
        "description": "Create a Delta table named 'products' from a DataFrame. Save it to the path '/delta/products'.",
        "category": "Delta Lake",
        "difficulty": "beginner",
        "points": 20,
        "order_index": 20,
        "starter_code": """# products_df has columns: product_id, name, category, price
# Create a Delta table at path '/delta/products'

# Your code here:
""",
        "solution_code": """products_df.write.format("delta").mode("overwrite").save("/delta/products")

# Or create as managed table:
# products_df.write.format("delta").saveAsTable("products")""",
        "expected_output": None,
        "hints": json.dumps([
            "Use .write.format('delta') for Delta format",
            ".mode('overwrite') or .mode('append')",
            ".save('path') for unmanaged table",
            ".saveAsTable('name') for managed table"
        ]),
        "test_cases": json.dumps([
            {"check": "contains", "value": "format"},
            {"check": "contains", "value": "delta"},
            {"check": "regex", "value": "save|saveAsTable"}
        ])
    },
    {
        "title": "Read Delta Table",
        "description": "Read the Delta table from '/delta/products' and display products with price greater than 100.",
        "category": "Delta Lake",
        "difficulty": "beginner",
        "points": 15,
        "order_index": 21,
        "starter_code": """# Read Delta table from '/delta/products'
# Filter products with price > 100

# Your code here:
""",
        "solution_code": """df = spark.read.format("delta").load("/delta/products")
result = df.filter(df.price > 100)
result.show()""",
        "expected_output": None,
        "hints": json.dumps([
            "Use spark.read.format('delta').load('path')",
            "Filter with .filter() or .where()",
            "Reference columns: df.column or col('column')"
        ]),
        "test_cases": json.dumps([
            {"check": "contains", "value": "read"},
            {"check": "contains", "value": "delta"},
            {"check": "contains", "value": "filter"},
            {"check": "contains", "value": "100"}
        ])
    },
    
    # ============== DELTA LAKE CHALLENGES - INTERMEDIATE ==============
    {
        "title": "Delta MERGE Operation",
        "description": "Perform a MERGE (upsert) operation on Delta table 'products'. Update existing records and insert new ones based on product_id.",
        "category": "Delta Lake",
        "difficulty": "intermediate",
        "points": 45,
        "order_index": 22,
        "starter_code": """from delta.tables import DeltaTable

# Existing Delta table at '/delta/products'
# New data in 'updates_df' with same schema
# Merge based on product_id: update if exists, insert if not

# Your code here:
""",
        "solution_code": """from delta.tables import DeltaTable

delta_table = DeltaTable.forPath(spark, "/delta/products")

delta_table.alias("target").merge(
    updates_df.alias("source"),
    "target.product_id = source.product_id"
).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()""",
        "expected_output": None,
        "hints": json.dumps([
            "DeltaTable.forPath() loads existing Delta table",
            "Use .alias() for table references in conditions",
            ".merge() starts the merge operation",
            "whenMatchedUpdateAll() updates matching rows",
            "whenNotMatchedInsertAll() inserts new rows"
        ]),
        "test_cases": json.dumps([
            {"check": "contains", "value": "DeltaTable"},
            {"check": "contains", "value": "merge"},
            {"check": "contains", "value": "whenMatched"},
            {"check": "contains", "value": "whenNotMatched"}
        ])
    },
    {
        "title": "Time Travel Query",
        "description": "Query the 'products' Delta table as it was 2 versions ago. Display the historical data.",
        "category": "Delta Lake",
        "difficulty": "intermediate",
        "points": 35,
        "order_index": 23,
        "starter_code": """# Query Delta table '/delta/products' at version 2 versions back
# Use time travel feature

# Your code here:
""",
        "solution_code": """# Query by version number
df_old = spark.read.format("delta").option("versionAsOf", 0).load("/delta/products")

# Alternative: Query by timestamp
# df_old = spark.read.format("delta").option("timestampAsOf", "2024-01-01").load("/delta/products")

df_old.show()""",
        "expected_output": None,
        "hints": json.dumps([
            "Use .option('versionAsOf', version_number)",
            "Or use .option('timestampAsOf', 'timestamp')",
            "Check available versions with DESCRIBE HISTORY",
            "Version 0 is the initial version"
        ]),
        "test_cases": json.dumps([
            {"check": "contains", "value": "option"},
            {"check": "regex", "value": "versionAsOf|timestampAsOf"}
        ])
    },
    
    # ============== DELTA LAKE CHALLENGES - ADVANCED ==============
    {
        "title": "Z-ORDER Optimization",
        "description": "Optimize the products Delta table using Z-ORDER on the 'category' and 'price' columns for faster queries.",
        "category": "Delta Lake",
        "difficulty": "advanced",
        "points": 50,
        "order_index": 24,
        "starter_code": """# Optimize Delta table at '/delta/products'
# Apply Z-ORDER optimization on category and price columns

# Your code here:
""",
        "solution_code": """from delta.tables import DeltaTable

delta_table = DeltaTable.forPath(spark, "/delta/products")

# Optimize with Z-ORDER
delta_table.optimize().executeZOrderBy("category", "price")

# Or using SQL:
# spark.sql("OPTIMIZE delta.`/delta/products` ZORDER BY (category, price)")""",
        "expected_output": None,
        "hints": json.dumps([
            "Load Delta table with DeltaTable.forPath()",
            "Use .optimize().executeZOrderBy() method",
            "Z-ORDER colocates related data for faster queries",
            "Choose columns frequently used in WHERE clauses"
        ]),
        "test_cases": json.dumps([
            {"check": "contains", "value": "optimize"},
            {"check": "regex", "value": "ZORDER|ZOrderBy|executeZOrderBy"}
        ])
    },
    {
        "title": "Vacuum and Table Maintenance",
        "description": "Clean up old files from the products Delta table, retaining only the last 7 days of history. Also display the table history.",
        "category": "Delta Lake",
        "difficulty": "advanced",
        "points": 45,
        "order_index": 25,
        "starter_code": """from delta.tables import DeltaTable

# Clean up files older than 7 days
# Display table history

# Your code here:
""",
        "solution_code": """from delta.tables import DeltaTable

delta_table = DeltaTable.forPath(spark, "/delta/products")

# Set retention to allow vacuum (default is 7 days)
spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", "false")

# Vacuum old files (168 hours = 7 days)
delta_table.vacuum(168)

# Display table history
delta_table.history().show()""",
        "expected_output": None,
        "hints": json.dumps([
            "vacuum() removes old data files",
            "Argument is retention hours (7 days = 168 hours)",
            "May need to disable retention check for < 7 days",
            ".history() shows table version history"
        ]),
        "test_cases": json.dumps([
            {"check": "contains", "value": "vacuum"},
            {"check": "contains", "value": "history"}
        ])
    }
]

# Badge definitions
BADGES = [
    # Milestone badges
    {"name": "First Steps", "description": "Complete your first challenge", "icon": "🎯", "criteria_type": "challenges", "criteria_value": 1, "rarity": "common"},
    {"name": "Getting Started", "description": "Complete 5 challenges", "icon": "🚀", "criteria_type": "challenges", "criteria_value": 5, "rarity": "common"},
    {"name": "Challenge Crusher", "description": "Complete 10 challenges", "icon": "💪", "criteria_type": "challenges", "criteria_value": 10, "rarity": "rare"},
    {"name": "Databricks Master", "description": "Complete 25 challenges", "icon": "🏆", "criteria_type": "challenges", "criteria_value": 25, "rarity": "epic"},
    {"name": "Legend", "description": "Complete all challenges", "icon": "👑", "criteria_type": "challenges", "criteria_value": 50, "rarity": "legendary"},
    
    # Points badges
    {"name": "Point Collector", "description": "Earn 100 points", "icon": "⭐", "criteria_type": "points", "criteria_value": 100, "rarity": "common"},
    {"name": "Point Hoarder", "description": "Earn 500 points", "icon": "🌟", "criteria_type": "points", "criteria_value": 500, "rarity": "rare"},
    {"name": "Point Master", "description": "Earn 1000 points", "icon": "✨", "criteria_type": "points", "criteria_value": 1000, "rarity": "epic"},
    
    # Streak badges
    {"name": "Consistent", "description": "Maintain a 3-day streak", "icon": "🔥", "criteria_type": "streak", "criteria_value": 3, "rarity": "common"},
    {"name": "Dedicated", "description": "Maintain a 7-day streak", "icon": "🔥", "criteria_type": "streak", "criteria_value": 7, "rarity": "rare"},
    {"name": "Unstoppable", "description": "Maintain a 30-day streak", "icon": "🔥", "criteria_type": "streak", "criteria_value": 30, "rarity": "legendary"},
    
    # Category badges
    {"name": "SQL Novice", "description": "Complete 3 SQL challenges", "icon": "📊", "criteria_type": "category", "criteria_value": 3, "criteria_category": "SQL", "rarity": "common"},
    {"name": "SQL Expert", "description": "Complete 10 SQL challenges", "icon": "📊", "criteria_type": "category", "criteria_value": 10, "criteria_category": "SQL", "rarity": "epic"},
    {"name": "PySpark Novice", "description": "Complete 3 PySpark challenges", "icon": "⚡", "criteria_type": "category", "criteria_value": 3, "criteria_category": "PySpark", "rarity": "common"},
    {"name": "PySpark Expert", "description": "Complete 10 PySpark challenges", "icon": "⚡", "criteria_type": "category", "criteria_value": 10, "criteria_category": "PySpark", "rarity": "epic"},
    {"name": "Delta Novice", "description": "Complete 3 Delta Lake challenges", "icon": "🔷", "criteria_type": "category", "criteria_value": 3, "criteria_category": "Delta Lake", "rarity": "common"},
    {"name": "Delta Expert", "description": "Complete 10 Delta Lake challenges", "icon": "🔷", "criteria_type": "category", "criteria_value": 10, "criteria_category": "Delta Lake", "rarity": "epic"},
]
