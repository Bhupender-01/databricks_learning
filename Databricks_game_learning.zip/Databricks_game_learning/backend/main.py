"""
Databricks Learning Platform - FastAPI Backend
A gamified learning platform for practicing Databricks skills.
"""
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from typing import List, Optional
import hashlib
import secrets
import json

from database import get_db, init_db, engine, Base
from models import User, Challenge, Submission, Badge, UserBadge
from schemas import (
    UserCreate, UserLogin, UserResponse, UserStats,
    ChallengeResponse, SubmissionCreate, SubmissionResponse,
    CodeValidationResult, BadgeResponse, UserBadgeResponse,
    LeaderboardEntry, LeaderboardResponse, LearningPath, DailyChallenge
)
from ai_validator import validate_submission
from challenges_data import CHALLENGES, BADGES

# Initialize FastAPI app
app = FastAPI(
    title="Databricks Learning Platform",
    description="A gamified platform for learning Databricks skills",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory session store (for simplicity)
sessions = {}

# ============== Helper Functions ==============

def hash_password(password: str) -> str:
    """Hash password using SHA-256."""
    return hashlib.sha256(password.encode()).hexdigest()

def verify_password(password: str, hashed: str) -> bool:
    """Verify password against hash."""
    return hash_password(password) == hashed

def create_session(user_id: int) -> str:
    """Create a new session token."""
    token = secrets.token_hex(32)
    sessions[token] = {"user_id": user_id, "created": datetime.utcnow()}
    return token

def get_current_user(token: str, db: Session) -> Optional[User]:
    """Get current user from session token."""
    if token not in sessions:
        return None
    session = sessions[token]
    # Check session expiry (24 hours)
    if datetime.utcnow() - session["created"] > timedelta(hours=24):
        del sessions[token]
        return None
    return db.query(User).filter(User.id == session["user_id"]).first()

def calculate_level(points: int) -> int:
    """Calculate user level based on points."""
    # Level formula: Level up every 100 points, with increasing difficulty
    if points < 50:
        return 1
    elif points < 150:
        return 2
    elif points < 300:
        return 3
    elif points < 500:
        return 4
    elif points < 750:
        return 5
    elif points < 1000:
        return 6
    elif points < 1500:
        return 7
    elif points < 2000:
        return 8
    elif points < 3000:
        return 9
    else:
        return 10

def check_and_award_badges(user: User, db: Session):
    """Check and award badges based on user progress."""
    badges = db.query(Badge).all()
    user_badge_ids = [ub.badge_id for ub in user.badges]
    
    for badge in badges:
        if badge.id in user_badge_ids:
            continue
            
        earned = False
        
        if badge.criteria_type == "challenges":
            earned = user.challenges_completed >= badge.criteria_value
        elif badge.criteria_type == "points":
            earned = user.total_points >= badge.criteria_value
        elif badge.criteria_type == "streak":
            earned = user.current_streak >= badge.criteria_value or user.longest_streak >= badge.criteria_value
        elif badge.criteria_type == "category":
            if badge.criteria_category == "SQL":
                earned = user.sql_completed >= badge.criteria_value
            elif badge.criteria_category == "PySpark":
                earned = user.pyspark_completed >= badge.criteria_value
            elif badge.criteria_category == "Delta Lake":
                earned = user.delta_completed >= badge.criteria_value
        
        if earned:
            user_badge = UserBadge(user_id=user.id, badge_id=badge.id)
            db.add(user_badge)
    
    db.commit()

# ============== Startup Events ==============

@app.on_event("startup")
async def startup():
    """Initialize database and seed data on startup."""
    # Create tables
    Base.metadata.create_all(bind=engine)
    
    db = next(get_db())
    try:
        # Seed challenges if empty
        if db.query(Challenge).count() == 0:
            for challenge_data in CHALLENGES:
                challenge = Challenge(**challenge_data)
                db.add(challenge)
            db.commit()
            print(f"Seeded {len(CHALLENGES)} challenges")
        
        # Seed badges if empty
        if db.query(Badge).count() == 0:
            for badge_data in BADGES:
                badge = Badge(**badge_data)
                db.add(badge)
            db.commit()
            print(f"Seeded {len(BADGES)} badges")
    finally:
        db.close()

# ============== Authentication Endpoints ==============

@app.post("/api/auth/register", response_model=dict)
async def register(user_data: UserCreate, db: Session = Depends(get_db)):
    """Register a new user."""
    # Check if user exists
    if db.query(User).filter(User.email == user_data.email).first():
        raise HTTPException(status_code=400, detail="Email already registered")
    if db.query(User).filter(User.username == user_data.username).first():
        raise HTTPException(status_code=400, detail="Username already taken")
    
    # Create user
    user = User(
        username=user_data.username,
        email=user_data.email,
        password_hash=hash_password(user_data.password),
        avatar=["🧑‍💻", "👨‍💻", "👩‍💻", "🦸", "🧙", "🥷"][hash(user_data.username) % 6]
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    
    # Create session
    token = create_session(user.id)
    
    return {"token": token, "user": UserResponse.model_validate(user)}

@app.post("/api/auth/login", response_model=dict)
async def login(credentials: UserLogin, db: Session = Depends(get_db)):
    """Login user."""
    user = db.query(User).filter(User.email == credentials.email).first()
    if not user or not verify_password(credentials.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    # Update streak
    today = datetime.utcnow().date()
    last_activity = user.last_activity.date() if user.last_activity else None
    
    if last_activity:
        days_diff = (today - last_activity).days
        if days_diff == 1:
            user.current_streak += 1
            if user.current_streak > user.longest_streak:
                user.longest_streak = user.current_streak
        elif days_diff > 1:
            user.current_streak = 1
    else:
        user.current_streak = 1
    
    user.last_activity = datetime.utcnow()
    db.commit()
    
    # Create session
    token = create_session(user.id)
    
    return {"token": token, "user": UserResponse.model_validate(user)}

@app.get("/api/auth/me", response_model=UserResponse)
async def get_me(token: str, db: Session = Depends(get_db)):
    """Get current user profile."""
    user = get_current_user(token, db)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    return UserResponse.model_validate(user)

@app.post("/api/auth/logout")
async def logout(token: str):
    """Logout user."""
    if token in sessions:
        del sessions[token]
    return {"message": "Logged out"}

# ============== Challenge Endpoints ==============

@app.get("/api/challenges", response_model=List[ChallengeResponse])
async def get_challenges(
    category: Optional[str] = None,
    difficulty: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """Get all challenges with optional filtering."""
    query = db.query(Challenge)
    if category:
        query = query.filter(Challenge.category == category)
    if difficulty:
        query = query.filter(Challenge.difficulty == difficulty)
    
    challenges = query.order_by(Challenge.order_index).all()
    return [ChallengeResponse.model_validate(c) for c in challenges]

@app.get("/api/challenges/{challenge_id}", response_model=ChallengeResponse)
async def get_challenge(challenge_id: int, db: Session = Depends(get_db)):
    """Get a specific challenge."""
    challenge = db.query(Challenge).filter(Challenge.id == challenge_id).first()
    if not challenge:
        raise HTTPException(status_code=404, detail="Challenge not found")
    return ChallengeResponse.model_validate(challenge)

@app.get("/api/challenges/daily", response_model=DailyChallenge)
async def get_daily_challenge(token: str, db: Session = Depends(get_db)):
    """Get today's daily challenge."""
    user = get_current_user(token, db)
    
    # Use date-based seed for consistent daily challenge
    today = datetime.utcnow().date()
    seed = int(today.strftime("%Y%m%d"))
    
    challenges = db.query(Challenge).all()
    if not challenges:
        raise HTTPException(status_code=404, detail="No challenges available")
    
    daily = challenges[seed % len(challenges)]
    
    # Check if user completed it today
    completed = False
    if user:
        today_start = datetime.combine(today, datetime.min.time())
        submission = db.query(Submission).filter(
            Submission.user_id == user.id,
            Submission.challenge_id == daily.id,
            Submission.is_correct == True,
            Submission.submitted_at >= today_start
        ).first()
        completed = submission is not None
    
    return DailyChallenge(
        challenge=ChallengeResponse.model_validate(daily),
        bonus_points=daily.points // 2,  # 50% bonus for daily
        completed=completed
    )

# ============== Submission Endpoints ==============

@app.post("/api/submit", response_model=CodeValidationResult)
async def submit_code(
    submission: SubmissionCreate,
    token: str,
    db: Session = Depends(get_db)
):
    """Submit code for validation."""
    user = get_current_user(token, db)
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    challenge = db.query(Challenge).filter(Challenge.id == submission.challenge_id).first()
    if not challenge:
        raise HTTPException(status_code=404, detail="Challenge not found")
    
    # Check if already completed
    existing = db.query(Submission).filter(
        Submission.user_id == user.id,
        Submission.challenge_id == challenge.id,
        Submission.is_correct == True
    ).first()
    
    already_completed = existing is not None
    
    # Validate code using AI validator
    challenge_dict = {
        'category': challenge.category,
        'solution_code': challenge.solution_code,
        'expected_output': challenge.expected_output,
        'hints': challenge.hints,
        'test_cases': challenge.test_cases
    }
    
    result = validate_submission(submission.code, challenge_dict)
    
    # Calculate points earned
    points_earned = 0
    if result['is_correct'] and not already_completed:
        points_earned = challenge.points
        
        # Check for daily bonus
        today = datetime.utcnow().date()
        seed = int(today.strftime("%Y%m%d"))
        challenges = db.query(Challenge).all()
        if challenges and challenges[seed % len(challenges)].id == challenge.id:
            points_earned += challenge.points // 2  # Daily bonus
        
        # Update user stats
        user.total_points += points_earned
        user.level = calculate_level(user.total_points)
        user.challenges_completed += 1
        
        # Update category stats
        if challenge.category == "SQL":
            user.sql_completed += 1
        elif challenge.category == "PySpark":
            user.pyspark_completed += 1
        elif challenge.category == "Delta Lake":
            user.delta_completed += 1
        
        user.last_activity = datetime.utcnow()
    
    # Save submission
    db_submission = Submission(
        user_id=user.id,
        challenge_id=challenge.id,
        code=submission.code,
        is_correct=result['is_correct'],
        points_earned=points_earned,
        ai_feedback=result['feedback'],
        execution_time=result['execution_time']
    )
    db.add(db_submission)
    db.commit()
    
    # Check for new badges
    if result['is_correct']:
        check_and_award_badges(user, db)
    
    return CodeValidationResult(
        is_correct=result['is_correct'],
        score=result['score'],
        feedback=result['feedback'],
        hints=result['hints'],
        execution_time=result['execution_time']
    )

@app.get("/api/submissions", response_model=List[SubmissionResponse])
async def get_submissions(token: str, challenge_id: Optional[int] = None, db: Session = Depends(get_db)):
    """Get user's submissions."""
    user = get_current_user(token, db)
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    query = db.query(Submission).filter(Submission.user_id == user.id)
    if challenge_id:
        query = query.filter(Submission.challenge_id == challenge_id)
    
    submissions = query.order_by(Submission.submitted_at.desc()).limit(50).all()
    return [SubmissionResponse.model_validate(s) for s in submissions]

# ============== Progress & Stats Endpoints ==============

@app.get("/api/stats", response_model=UserStats)
async def get_user_stats(token: str, db: Session = Depends(get_db)):
    """Get user statistics and progress."""
    user = get_current_user(token, db)
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    # Calculate rank
    rank = db.query(User).filter(User.total_points > user.total_points).count() + 1
    
    # Calculate category progress
    total_sql = db.query(Challenge).filter(Challenge.category == "SQL").count()
    total_pyspark = db.query(Challenge).filter(Challenge.category == "PySpark").count()
    total_delta = db.query(Challenge).filter(Challenge.category == "Delta Lake").count()
    
    return UserStats(
        total_points=user.total_points,
        level=user.level,
        rank=rank,
        challenges_completed=user.challenges_completed,
        current_streak=user.current_streak,
        longest_streak=user.longest_streak,
        badges_earned=len(user.badges),
        category_progress={
            "SQL": {"completed": user.sql_completed, "total": total_sql},
            "PySpark": {"completed": user.pyspark_completed, "total": total_pyspark},
            "Delta Lake": {"completed": user.delta_completed, "total": total_delta}
        }
    )

@app.get("/api/learning-paths", response_model=List[LearningPath])
async def get_learning_paths(token: str, db: Session = Depends(get_db)):
    """Get learning paths progress for each category."""
    user = get_current_user(token, db)
    
    paths = []
    for category in ["SQL", "PySpark", "Delta Lake"]:
        challenges = db.query(Challenge).filter(Challenge.category == category).order_by(Challenge.order_index).all()
        total = len(challenges)
        
        completed = 0
        next_id = None
        current_difficulty = "beginner"
        
        if user:
            # Get completed challenge IDs
            completed_ids = set(
                s.challenge_id for s in db.query(Submission).filter(
                    Submission.user_id == user.id,
                    Submission.is_correct == True
                ).all()
            )
            
            for c in challenges:
                if c.id in completed_ids:
                    completed += 1
                elif next_id is None:
                    next_id = c.id
                    current_difficulty = c.difficulty
        
        progress = (completed / total * 100) if total > 0 else 0
        
        paths.append(LearningPath(
            category=category,
            total_challenges=total,
            completed_challenges=completed,
            progress_percentage=round(progress, 1),
            current_difficulty=current_difficulty,
            next_challenge_id=next_id
        ))
    
    return paths

# ============== Leaderboard Endpoints ==============

@app.get("/api/leaderboard", response_model=LeaderboardResponse)
async def get_leaderboard(
    token: Optional[str] = None,
    limit: int = 10,
    db: Session = Depends(get_db)
):
    """Get global leaderboard."""
    users = db.query(User).order_by(User.total_points.desc()).limit(limit).all()
    
    entries = []
    for i, u in enumerate(users, 1):
        entries.append(LeaderboardEntry(
            rank=i,
            user_id=u.id,
            username=u.username,
            avatar=u.avatar,
            total_points=u.total_points,
            level=u.level,
            challenges_completed=u.challenges_completed
        ))
    
    user_rank = None
    if token:
        user = get_current_user(token, db)
        if user:
            user_rank = db.query(User).filter(User.total_points > user.total_points).count() + 1
    
    return LeaderboardResponse(entries=entries, user_rank=user_rank)

# ============== Badge Endpoints ==============

@app.get("/api/badges", response_model=List[BadgeResponse])
async def get_all_badges(db: Session = Depends(get_db)):
    """Get all available badges."""
    badges = db.query(Badge).all()
    return [BadgeResponse.model_validate(b) for b in badges]

@app.get("/api/my-badges", response_model=List[UserBadgeResponse])
async def get_my_badges(token: str, db: Session = Depends(get_db)):
    """Get user's earned badges."""
    user = get_current_user(token, db)
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    return [
        UserBadgeResponse(
            badge=BadgeResponse.model_validate(ub.badge),
            earned_at=ub.earned_at
        )
        for ub in user.badges
    ]

# ============== Run Server ==============

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)
