"""
SQLAlchemy models for the Databricks Learning Platform.
"""
from sqlalchemy import Column, Integer, String, Text, Boolean, DateTime, ForeignKey, Float
from sqlalchemy.orm import relationship
from datetime import datetime
from database import Base

class User(Base):
    """User model for storing user information and progress."""
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, index=True, nullable=False)
    email = Column(String(100), unique=True, index=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    avatar = Column(String(50), default="🧑‍💻")
    
    # Progress tracking
    total_points = Column(Integer, default=0)
    level = Column(Integer, default=1)
    current_streak = Column(Integer, default=0)
    longest_streak = Column(Integer, default=0)
    last_activity = Column(DateTime, default=datetime.utcnow)
    
    # Stats
    challenges_completed = Column(Integer, default=0)
    sql_completed = Column(Integer, default=0)
    pyspark_completed = Column(Integer, default=0)
    delta_completed = Column(Integer, default=0)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    submissions = relationship("Submission", back_populates="user")
    badges = relationship("UserBadge", back_populates="user")


class Challenge(Base):
    """Challenge model for storing coding exercises."""
    __tablename__ = "challenges"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(200), nullable=False)
    description = Column(Text, nullable=False)
    category = Column(String(50), nullable=False)  # SQL, PySpark, Delta Lake
    difficulty = Column(String(20), nullable=False)  # beginner, intermediate, advanced, expert
    points = Column(Integer, default=10)
    
    # Code content
    starter_code = Column(Text, nullable=False)
    solution_code = Column(Text, nullable=False)
    expected_output = Column(Text)
    
    # Hints (JSON array stored as string)
    hints = Column(Text, default="[]")
    
    # Test cases (JSON array stored as string)
    test_cases = Column(Text, default="[]")
    
    # Ordering
    order_index = Column(Integer, default=0)
    is_daily = Column(Boolean, default=False)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    submissions = relationship("Submission", back_populates="challenge")


class Submission(Base):
    """Submission model for tracking user attempts."""
    __tablename__ = "submissions"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    challenge_id = Column(Integer, ForeignKey("challenges.id"), nullable=False)
    
    code = Column(Text, nullable=False)
    is_correct = Column(Boolean, default=False)
    points_earned = Column(Integer, default=0)
    
    # AI feedback
    ai_feedback = Column(Text)
    execution_time = Column(Float)
    
    submitted_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    user = relationship("User", back_populates="submissions")
    challenge = relationship("Challenge", back_populates="submissions")


class Badge(Base):
    """Badge model for achievements."""
    __tablename__ = "badges"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    description = Column(Text, nullable=False)
    icon = Column(String(50), nullable=False)  # Emoji or icon class
    
    # Criteria
    criteria_type = Column(String(50), nullable=False)  # points, challenges, streak, category
    criteria_value = Column(Integer, nullable=False)
    criteria_category = Column(String(50))  # For category-specific badges
    
    # Rarity
    rarity = Column(String(20), default="common")  # common, rare, epic, legendary
    
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    users = relationship("UserBadge", back_populates="badge")


class UserBadge(Base):
    """Association table for user badges."""
    __tablename__ = "user_badges"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    badge_id = Column(Integer, ForeignKey("badges.id"), nullable=False)
    earned_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    user = relationship("User", back_populates="badges")
    badge = relationship("Badge", back_populates="users")
