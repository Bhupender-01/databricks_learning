"""
Pydantic schemas for request/response validation.
"""
from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime

# ============== User Schemas ==============

class UserCreate(BaseModel):
    username: str
    email: EmailStr
    password: str

class UserLogin(BaseModel):
    email: str
    password: str

class UserResponse(BaseModel):
    id: int
    username: str
    email: str
    avatar: str
    total_points: int
    level: int
    current_streak: int
    longest_streak: int
    challenges_completed: int
    sql_completed: int
    pyspark_completed: int
    delta_completed: int
    created_at: datetime

    class Config:
        from_attributes = True

class UserStats(BaseModel):
    total_points: int
    level: int
    rank: int
    challenges_completed: int
    current_streak: int
    longest_streak: int
    badges_earned: int
    category_progress: dict

# ============== Challenge Schemas ==============

class ChallengeBase(BaseModel):
    title: str
    description: str
    category: str
    difficulty: str
    points: int
    starter_code: str

class ChallengeResponse(ChallengeBase):
    id: int
    hints: str
    is_daily: bool
    order_index: int

    class Config:
        from_attributes = True

class ChallengeFull(ChallengeResponse):
    solution_code: str
    expected_output: Optional[str]
    test_cases: str

# ============== Submission Schemas ==============

class SubmissionCreate(BaseModel):
    challenge_id: int
    code: str

class SubmissionResponse(BaseModel):
    id: int
    challenge_id: int
    code: str
    is_correct: bool
    points_earned: int
    ai_feedback: Optional[str]
    submitted_at: datetime

    class Config:
        from_attributes = True

class CodeValidationResult(BaseModel):
    is_correct: bool
    score: int
    feedback: str
    hints: List[str]
    execution_time: Optional[float]

# ============== Badge Schemas ==============

class BadgeResponse(BaseModel):
    id: int
    name: str
    description: str
    icon: str
    rarity: str

    class Config:
        from_attributes = True

class UserBadgeResponse(BaseModel):
    badge: BadgeResponse
    earned_at: datetime

# ============== Leaderboard Schemas ==============

class LeaderboardEntry(BaseModel):
    rank: int
    user_id: int
    username: str
    avatar: str
    total_points: int
    level: int
    challenges_completed: int

class LeaderboardResponse(BaseModel):
    entries: List[LeaderboardEntry]
    user_rank: Optional[int]

# ============== Progress Schemas ==============

class LearningPath(BaseModel):
    category: str
    total_challenges: int
    completed_challenges: int
    progress_percentage: float
    current_difficulty: str
    next_challenge_id: Optional[int]

class DailyChallenge(BaseModel):
    challenge: ChallengeResponse
    bonus_points: int
    completed: bool
