/**
 * Databricks Learning Platform - Main JavaScript
 * Handles authentication, API calls, and UI interactions
 */

// API Configuration
const API_BASE = 'http://localhost:8000/api';

// Storage keys
const TOKEN_KEY = 'databricks_token';
const USER_KEY = 'databricks_user';

// ==========================================
// UTILITY FUNCTIONS
// ==========================================

/**
 * Make API request with authentication
 */
async function apiRequest(endpoint, options = {}) {
    const token = localStorage.getItem(TOKEN_KEY);
    
    const config = {
        headers: {
            'Content-Type': 'application/json',
            ...options.headers
        },
        ...options
    };
    
    // Add token to query params if needed
    let url = `${API_BASE}${endpoint}`;
    if (token && !options.noAuth) {
        url += url.includes('?') ? `&token=${token}` : `?token=${token}`;
    }
    
    try {
        const response = await fetch(url, config);
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.detail || 'API request failed');
        }
        
        return data;
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}

/**
 * Get stored user data
 */
function getStoredUser() {
    const data = localStorage.getItem(USER_KEY);
    return data ? JSON.parse(data) : null;
}

/**
 * Store user data
 */
function storeUser(user) {
    localStorage.setItem(USER_KEY, JSON.stringify(user));
}

/**
 * Clear stored auth data
 */
function clearAuth() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
}

/**
 * Format number with commas
 */
function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

/**
 * Show toast notification
 */
function showToast(message, type = 'info') {
    // Remove existing toast
    const existing = document.querySelector('.toast');
    if (existing) existing.remove();
    
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <span class="toast-icon">${type === 'success' ? '✅' : type === 'error' ? '❌' : 'ℹ️'}</span>
        <span class="toast-message">${message}</span>
    `;
    
    document.body.appendChild(toast);
    
    // Add styles if not exist
    if (!document.getElementById('toast-styles')) {
        const style = document.createElement('style');
        style.id = 'toast-styles';
        style.textContent = `
            .toast {
                position: fixed;
                bottom: 20px;
                right: 20px;
                display: flex;
                align-items: center;
                gap: 8px;
                padding: 12px 20px;
                background: var(--bg-secondary);
                border: 1px solid var(--border-color);
                border-radius: var(--radius-md);
                box-shadow: var(--shadow-lg);
                z-index: 3000;
                animation: slideIn 0.3s ease;
            }
            .toast-success { border-color: var(--success); }
            .toast-error { border-color: var(--error); }
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
        `;
        document.head.appendChild(style);
    }
    
    // Auto remove
    setTimeout(() => {
        toast.style.animation = 'slideIn 0.3s ease reverse';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// ==========================================
// AUTHENTICATION
// ==========================================

/**
 * Check authentication status and update UI
 */
async function checkAuthStatus() {
    const token = localStorage.getItem(TOKEN_KEY);
    const navAuth = document.getElementById('navAuth');
    const navUser = document.getElementById('navUser');
    const userPoints = document.getElementById('userPoints');
    
    if (!navAuth || !navUser) return;
    
    if (token) {
        try {
            const user = await apiRequest('/auth/me');
            storeUser(user);
            
            navAuth.style.display = 'none';
            navUser.style.display = 'flex';
            if (userPoints) {
                userPoints.textContent = `${formatNumber(user.total_points)} pts`;
            }
        } catch (error) {
            // Token invalid, clear and show login
            clearAuth();
            navAuth.style.display = 'flex';
            navUser.style.display = 'none';
        }
    } else {
        navAuth.style.display = 'flex';
        navUser.style.display = 'none';
    }
}

/**
 * Show auth modal
 */
function showAuthModal(type = 'login') {
    const modal = document.getElementById('authModal');
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const authError = document.getElementById('authError');
    
    if (!modal) return;
    
    modal.classList.add('active');
    authError.style.display = 'none';
    
    if (type === 'login') {
        loginForm.style.display = 'block';
        registerForm.style.display = 'none';
    } else {
        loginForm.style.display = 'none';
        registerForm.style.display = 'block';
    }
}

/**
 * Close auth modal
 */
function closeAuthModal() {
    const modal = document.getElementById('authModal');
    if (modal) {
        modal.classList.remove('active');
    }
}

/**
 * Handle login form submission
 */
async function handleLogin(event) {
    event.preventDefault();
    
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    const authError = document.getElementById('authError');
    
    try {
        const data = await apiRequest('/auth/login', {
            method: 'POST',
            body: JSON.stringify({ email, password }),
            noAuth: true
        });
        
        localStorage.setItem(TOKEN_KEY, data.token);
        storeUser(data.user);
        
        closeAuthModal();
        showToast('Welcome back! 🎉', 'success');
        
        // Redirect to dashboard or refresh
        if (window.location.pathname.includes('index')) {
            window.location.href = 'dashboard.html';
        } else {
            window.location.reload();
        }
    } catch (error) {
        authError.textContent = error.message || 'Login failed. Please try again.';
        authError.style.display = 'block';
    }
}

/**
 * Handle registration form submission
 */
async function handleRegister(event) {
    event.preventDefault();
    
    const username = document.getElementById('registerUsername').value;
    const email = document.getElementById('registerEmail').value;
    const password = document.getElementById('registerPassword').value;
    const authError = document.getElementById('authError');
    
    try {
        const data = await apiRequest('/auth/register', {
            method: 'POST',
            body: JSON.stringify({ username, email, password }),
            noAuth: true
        });
        
        localStorage.setItem(TOKEN_KEY, data.token);
        storeUser(data.user);
        
        closeAuthModal();
        showToast('Account created! Welcome aboard! 🚀', 'success');
        
        // Redirect to dashboard
        window.location.href = 'dashboard.html';
    } catch (error) {
        authError.textContent = error.message || 'Registration failed. Please try again.';
        authError.style.display = 'block';
    }
}

/**
 * Handle logout
 */
async function handleLogout() {
    const token = localStorage.getItem(TOKEN_KEY);
    
    try {
        await apiRequest('/auth/logout', {
            method: 'POST'
        });
    } catch (error) {
        console.error('Logout error:', error);
    }
    
    clearAuth();
    window.location.href = 'index.html';
}

// ==========================================
// CHALLENGES
// ==========================================

/**
 * Load challenges with optional filters
 */
async function loadChallenges(category = null, difficulty = null) {
    let endpoint = '/challenges';
    const params = [];
    
    if (category) params.push(`category=${encodeURIComponent(category)}`);
    if (difficulty) params.push(`difficulty=${difficulty}`);
    
    if (params.length > 0) {
        endpoint += '?' + params.join('&');
    }
    
    return await apiRequest(endpoint, { noAuth: true });
}

/**
 * Load specific challenge
 */
async function loadChallenge(challengeId) {
    return await apiRequest(`/challenges/${challengeId}`, { noAuth: true });
}

/**
 * Submit code for validation
 */
async function submitCode(challengeId, code) {
    return await apiRequest('/submit', {
        method: 'POST',
        body: JSON.stringify({ challenge_id: challengeId, code })
    });
}

// ==========================================
// USER DATA
// ==========================================

/**
 * Load user stats
 */
async function loadUserStats() {
    return await apiRequest('/stats');
}

/**
 * Load learning paths progress
 */
async function loadLearningPaths() {
    return await apiRequest('/learning-paths');
}

/**
 * Load user's badges
 */
async function loadUserBadges() {
    return await apiRequest('/my-badges');
}

/**
 * Load user's submissions
 */
async function loadSubmissions(challengeId = null) {
    let endpoint = '/submissions';
    if (challengeId) {
        endpoint += `?challenge_id=${challengeId}`;
    }
    return await apiRequest(endpoint);
}

// ==========================================
// LEADERBOARD
// ==========================================

/**
 * Load leaderboard
 */
async function loadLeaderboard(limit = 10) {
    const token = localStorage.getItem(TOKEN_KEY);
    let endpoint = `/leaderboard?limit=${limit}`;
    if (token) {
        endpoint += `&token=${token}`;
    }
    return await apiRequest(endpoint, { noAuth: true });
}

// ==========================================
// UI HELPERS
// ==========================================

/**
 * Scroll to features section
 */
function scrollToFeatures() {
    const features = document.getElementById('features');
    if (features) {
        features.scrollIntoView({ behavior: 'smooth' });
    }
}

/**
 * Require authentication for page
 */
function requireAuth() {
    const token = localStorage.getItem(TOKEN_KEY);
    if (!token) {
        window.location.href = 'index.html';
        return false;
    }
    return true;
}

/**
 * Get difficulty color class
 */
function getDifficultyColor(difficulty) {
    const colors = {
        beginner: 'var(--success)',
        intermediate: 'var(--warning)',
        advanced: 'var(--error)',
        expert: 'var(--accent-secondary)'
    };
    return colors[difficulty] || 'var(--text-secondary)';
}

/**
 * Get category icon
 */
function getCategoryIcon(category) {
    const icons = {
        'SQL': '📊',
        'PySpark': '⚡',
        'Delta Lake': '🔷'
    };
    return icons[category] || '📝';
}

/**
 * Get rarity color
 */
function getRarityColor(rarity) {
    const colors = {
        common: '#9ca3af',
        rare: '#3b82f6',
        epic: '#a855f7',
        legendary: '#f59e0b'
    };
    return colors[rarity] || '#9ca3af';
}

// ==========================================
// EXPORT FOR MODULE USE
// ==========================================

// Make functions globally available
window.apiRequest = apiRequest;
window.getStoredUser = getStoredUser;
window.checkAuthStatus = checkAuthStatus;
window.showAuthModal = showAuthModal;
window.closeAuthModal = closeAuthModal;
window.handleLogin = handleLogin;
window.handleRegister = handleRegister;
window.handleLogout = handleLogout;
window.loadChallenges = loadChallenges;
window.loadChallenge = loadChallenge;
window.submitCode = submitCode;
window.loadUserStats = loadUserStats;
window.loadLearningPaths = loadLearningPaths;
window.loadUserBadges = loadUserBadges;
window.loadSubmissions = loadSubmissions;
window.loadLeaderboard = loadLeaderboard;
window.requireAuth = requireAuth;
window.showToast = showToast;
window.formatNumber = formatNumber;
window.getDifficultyColor = getDifficultyColor;
window.getCategoryIcon = getCategoryIcon;
window.getRarityColor = getRarityColor;
window.scrollToFeatures = scrollToFeatures;
