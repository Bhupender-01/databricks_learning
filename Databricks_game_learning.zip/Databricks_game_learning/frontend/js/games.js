/**
 * Interactive Learning Games - Core Game Engine
 * Fun mini-games that teach Databricks concepts
 */

// ==========================================
// GAME STATE
// ==========================================

const GameEngine = {
    lives: 5,
    coins: 0,
    currentXP: 350,
    level: 1,
    streak: 0,
    powerups: {
        hints: 3,
        skips: 1,
        freezes: 2,
        doubleXP: false
    },
    currentGame: null,
    gameScore: 0,
    // Game Unlocks Configuration
    gameUnlocks: {
        'puzzle': { requiredUnit: 0, requiredLevel: 1 },
        'quiz': { requiredUnit: 0, requiredLevel: 1 },
        'memory': { requiredUnit: 0, requiredLevel: 1 },
        'bughunter': { requiredUnit: 0, requiredLevel: 2 },
        'speedcoder': { requiredUnit: 0, requiredLevel: 2 },
        'flashcards': { requiredUnit: 1, requiredLevel: 1 }, // Unit 1
        'fillblanks': { requiredUnit: 2, requiredLevel: 3 }, // Unit 2
        'querypredict': { requiredUnit: 3, requiredLevel: 4 }, // Unit 3
        'schemabuilder': { requiredUnit: 2, requiredLevel: 3 }, // Unit 2
        'joinmaster': { requiredUnit: 4, requiredLevel: 5 }, // Unit 4
        'boss': { requiredUnit: 5, requiredLevel: 10 } // Unit 5
    },
    learningStats: {
        units: 0,
        skills: 0,
        crowns: 0
    }
};

// ==========================================
// PUZZLE GAME DATA
// ==========================================

const puzzleQuestions = [
    // LEVEL 1 - SQL Basics
    {
        id: 1, level: 1,
        question: "Build a query to select all columns from the employees table",
        description: "Arrange the blocks to form a valid SELECT statement",
        blocks: ["SELECT", "*", "FROM", "employees", "WHERE", "AND"],
        correctOrder: ["SELECT", "*", "FROM", "employees"],
        category: "SQL", difficulty: "easy", xp: 20
    },
    {
        id: 2, level: 1,
        question: "Filter employees with salary greater than 50000",
        description: "Build a query with a WHERE clause",
        blocks: ["SELECT", "*", "FROM", "employees", "WHERE", "salary", ">", "50000", "ORDER BY"],
        correctOrder: ["SELECT", "*", "FROM", "employees", "WHERE", "salary", ">", "50000"],
        category: "SQL", difficulty: "easy", xp: 25
    },
    {
        id: 3, level: 1,
        question: "Select specific columns: name and email",
        description: "Select only the columns you need",
        blocks: ["SELECT", "name", ",", "email", "FROM", "users", "*", "WHERE"],
        correctOrder: ["SELECT", "name", ",", "email", "FROM", "users"],
        category: "SQL", difficulty: "easy", xp: 20
    },
    // LEVEL 2 - SQL Aggregations
    {
        id: 4, level: 2,
        question: "Count employees grouped by department",
        description: "Use GROUP BY to aggregate data",
        blocks: ["SELECT", "department", ",", "COUNT(*)", "FROM", "employees", "GROUP BY", "department", "ORDER BY"],
        correctOrder: ["SELECT", "department", ",", "COUNT(*)", "FROM", "employees", "GROUP BY", "department"],
        category: "SQL", difficulty: "medium", xp: 35
    },
    {
        id: 5, level: 2,
        question: "Calculate average salary by department",
        description: "Use AVG() aggregate function",
        blocks: ["SELECT", "department", ",", "AVG(salary)", "FROM", "employees", "GROUP BY", "department", "SUM"],
        correctOrder: ["SELECT", "department", ",", "AVG(salary)", "FROM", "employees", "GROUP BY", "department"],
        category: "SQL", difficulty: "medium", xp: 35
    },
    {
        id: 6, level: 2,
        question: "Find departments with more than 10 employees",
        description: "Use HAVING to filter grouped results",
        blocks: ["SELECT", "department", ",", "COUNT(*)", "FROM", "employees", "GROUP BY", "department", "HAVING", "COUNT(*)", ">", "10"],
        correctOrder: ["SELECT", "department", ",", "COUNT(*)", "FROM", "employees", "GROUP BY", "department", "HAVING", "COUNT(*)", ">", "10"],
        category: "SQL", difficulty: "medium", xp: 40
    },
    // LEVEL 3 - SQL Joins
    {
        id: 7, level: 3,
        question: "Join employees with departments table",
        description: "Use INNER JOIN to combine tables",
        blocks: ["SELECT", "*", "FROM", "employees", "e", "INNER JOIN", "departments", "d", "ON", "e.dept_id", "=", "d.id"],
        correctOrder: ["SELECT", "*", "FROM", "employees", "e", "INNER JOIN", "departments", "d", "ON", "e.dept_id", "=", "d.id"],
        category: "SQL", difficulty: "hard", xp: 50
    },
    {
        id: 8, level: 3,
        question: "Left join to include all employees",
        description: "LEFT JOIN keeps all rows from left table",
        blocks: ["SELECT", "*", "FROM", "employees", "LEFT JOIN", "departments", "ON", "employees.dept_id", "=", "departments.id", "INNER"],
        correctOrder: ["SELECT", "*", "FROM", "employees", "LEFT JOIN", "departments", "ON", "employees.dept_id", "=", "departments.id"],
        category: "SQL", difficulty: "hard", xp: 50
    },
    // LEVEL 4 - PySpark Basics
    {
        id: 9, level: 4,
        question: "Create a PySpark DataFrame filter",
        description: "Filter a DataFrame for age > 25",
        blocks: ["df", ".filter", "(", "col", "(", '"age"', ")", ">", "25", ")", ".show()"],
        correctOrder: ["df", ".filter", "(", "col", "(", '"age"', ")", ">", "25", ")"],
        category: "PySpark", difficulty: "medium", xp: 40
    },
    {
        id: 10, level: 4,
        question: "Select columns in PySpark",
        description: "Use select() to choose columns",
        blocks: ["df", ".select", "(", '"name"', ",", '"salary"', ")", ".show()", ".filter"],
        correctOrder: ["df", ".select", "(", '"name"', ",", '"salary"', ")"],
        category: "PySpark", difficulty: "medium", xp: 35
    },
    {
        id: 11, level: 4,
        question: "Add a new column with withColumn",
        description: "Create a bonus column",
        blocks: ["df", ".withColumn", "(", '"bonus"', ",", "col", "(", '"salary"', ")", "*", "0.1", ")"],
        correctOrder: ["df", ".withColumn", "(", '"bonus"', ",", "col", "(", '"salary"', ")", "*", "0.1", ")"],
        category: "PySpark", difficulty: "hard", xp: 45
    },
    // LEVEL 5 - PySpark Advanced
    {
        id: 12, level: 5,
        question: "Group by and aggregate in PySpark",
        description: "Calculate sum of sales by region",
        blocks: ["df", ".groupBy", "(", '"region"', ")", ".agg", "(", "sum", "(", '"sales"', ")", ")", ".show"],
        correctOrder: ["df", ".groupBy", "(", '"region"', ")", ".agg", "(", "sum", "(", '"sales"', ")", ")"],
        category: "PySpark", difficulty: "hard", xp: 50
    },
    {
        id: 13, level: 5,
        question: "Join two DataFrames",
        description: "Inner join on customer_id",
        blocks: ["orders", ".join", "(", "customers", ",", '"customer_id"', ",", '"inner"', ")", ".select"],
        correctOrder: ["orders", ".join", "(", "customers", ",", '"customer_id"', ",", '"inner"', ")"],
        category: "PySpark", difficulty: "hard", xp: 55
    },
    // LEVEL 6 - Delta Lake
    {
        id: 14, level: 6,
        question: "Read a Delta table",
        description: "Load a Delta table from a path",
        blocks: ["spark", ".read", ".format", "(", '"delta"', ")", ".load", "(", '"/path"', ")"],
        correctOrder: ["spark", ".read", ".format", "(", '"delta"', ")", ".load", "(", '"/path"', ")"],
        category: "Delta Lake", difficulty: "medium", xp: 35
    },
    {
        id: 15, level: 6,
        question: "Write DataFrame as Delta table",
        description: "Save data in Delta format",
        blocks: ["df", ".write", ".format", "(", '"delta"', ")", ".mode", "(", '"overwrite"', ")", ".save", "(", '"/output"', ")"],
        correctOrder: ["df", ".write", ".format", "(", '"delta"', ")", ".mode", "(", '"overwrite"', ")", ".save", "(", '"/output"', ")"],
        category: "Delta Lake", difficulty: "hard", xp: 50
    },
    {
        id: 16, level: 6,
        question: "Time travel to version 5",
        description: "Read historical version of Delta table",
        blocks: ["spark", ".read", ".format", "(", '"delta"', ")", ".option", "(", '"versionAsOf"', ",", "5", ")", ".load", "(", '"/path"', ")"],
        correctOrder: ["spark", ".read", ".format", "(", '"delta"', ")", ".option", "(", '"versionAsOf"', ",", "5", ")", ".load", "(", '"/path"', ")"],
        category: "Delta Lake", difficulty: "hard", xp: 60
    },
    // LEVEL 7 - Delta Lake Advanced
    {
        id: 17, level: 7,
        question: "Create a MERGE statement",
        description: "Upsert data into Delta table",
        blocks: ["MERGE INTO", "target", "USING", "source", "ON", "target.id", "=", "source.id", "WHEN MATCHED", "THEN UPDATE", "SET *"],
        correctOrder: ["MERGE INTO", "target", "USING", "source", "ON", "target.id", "=", "source.id", "WHEN MATCHED", "THEN UPDATE", "SET *"],
        category: "Delta Lake", difficulty: "expert", xp: 70
    },
    {
        id: 18, level: 7,
        question: "Optimize Delta table",
        description: "Compact small files",
        blocks: ["OPTIMIZE", "delta.`/path/to/table`", "ZORDER BY", "(", "date", ")", "WHERE", "VACUUM"],
        correctOrder: ["OPTIMIZE", "delta.`/path/to/table`", "ZORDER BY", "(", "date", ")"],
        category: "Delta Lake", difficulty: "expert", xp: 65
    }
];

// ==========================================
// QUIZ BATTLE DATA - EXPANDED
// ==========================================

const quizQuestions = [
    // SQL Basics
    { question: "What SQL keyword is used to filter rows?", options: ["SELECT", "WHERE", "FROM", "GROUP BY"], correct: 1, category: "SQL", level: 1 },
    { question: "Which function counts the number of rows?", options: ["SUM()", "COUNT(*)", "AVG()", "MAX()"], correct: 1, category: "SQL", level: 1 },
    { question: "What does GROUP BY do?", options: ["Sorts results", "Filters rows", "Groups rows for aggregation", "Joins tables"], correct: 2, category: "SQL", level: 1 },
    { question: "Which keyword sorts results in descending order?", options: ["ASC", "DESC", "DOWN", "REVERSE"], correct: 1, category: "SQL", level: 1 },
    { question: "What does DISTINCT do?", options: ["Counts rows", "Removes duplicates", "Sorts data", "Filters nulls"], correct: 1, category: "SQL", level: 1 },
    // SQL Intermediate
    { question: "Which JOIN returns all rows from left table?", options: ["INNER JOIN", "LEFT JOIN", "RIGHT JOIN", "CROSS JOIN"], correct: 1, category: "SQL", level: 2 },
    { question: "What filters grouped results?", options: ["WHERE", "HAVING", "GROUP BY", "ORDER BY"], correct: 1, category: "SQL", level: 2 },
    { question: "Which is NOT an aggregate function?", options: ["SUM", "AVG", "CONCAT", "COUNT"], correct: 2, category: "SQL", level: 2 },
    { question: "What does UNION do?", options: ["Joins tables", "Combines result sets", "Creates views", "Deletes data"], correct: 1, category: "SQL", level: 2 },
    { question: "NULL = NULL returns?", options: ["TRUE", "FALSE", "NULL", "Error"], correct: 2, category: "SQL", level: 2 },
    // SQL Advanced
    { question: "What is a CTE?", options: ["Common Table Expression", "Complex Type Entity", "Cached Table Entry", "Column Type Extension"], correct: 0, category: "SQL", level: 3 },
    { question: "Which is faster for existence check?", options: ["IN", "EXISTS", "JOIN", "UNION"], correct: 1, category: "SQL", level: 3 },
    { question: "Window function keyword?", options: ["PARTITION BY", "GROUP BY", "ORDER BY", "SPLIT BY"], correct: 0, category: "SQL", level: 3 },
    // PySpark Basics
    { question: "In PySpark, how do you select columns?", options: [".filter()", ".select()", ".where()", ".groupBy()"], correct: 1, category: "PySpark", level: 4 },
    { question: "How do you add a column in PySpark?", options: [".addColumn()", ".withColumn()", ".newColumn()", ".insertColumn()"], correct: 1, category: "PySpark", level: 4 },
    { question: "Which shows DataFrame content?", options: [".display()", ".show()", ".print()", ".view()"], correct: 1, category: "PySpark", level: 4 },
    { question: "How to rename a column?", options: [".rename()", ".withColumnRenamed()", ".setName()", ".alias()"], correct: 1, category: "PySpark", level: 4 },
    // PySpark Intermediate
    { question: "Which creates a temporary view?", options: [".createView()", ".createOrReplaceTempView()", ".tempView()", ".registerView()"], correct: 1, category: "PySpark", level: 5 },
    { question: "How to cache a DataFrame?", options: [".save()", ".cache()", ".store()", ".memory()"], correct: 1, category: "PySpark", level: 5 },
    { question: "Which handles missing values?", options: [".drop()", ".na.drop()", ".null.drop()", ".removeNull()"], correct: 1, category: "PySpark", level: 5 },
    { question: "How to repartition data?", options: [".split()", ".repartition()", ".partition()", ".divide()"], correct: 1, category: "PySpark", level: 5 },
    // PySpark Advanced
    { question: "What is a UDF?", options: ["User Defined Function", "Universal Data Format", "Unified Distribution Framework", "User Data File"], correct: 0, category: "PySpark", level: 6 },
    { question: "Which is lazily evaluated?", options: [".show()", ".collect()", ".filter()", ".count()"], correct: 2, category: "PySpark", level: 6 },
    { question: "Broadcast variable purpose?", options: ["Large joins", "Small lookup tables", "Streaming data", "File output"], correct: 1, category: "PySpark", level: 6 },
    // Delta Lake Basics
    { question: "What is Delta Lake's main advantage?", options: ["Faster queries", "ACID transactions", "Smaller files", "No schema"], correct: 1, category: "Delta Lake", level: 7 },
    { question: "What does MERGE in Delta Lake do?", options: ["Deletes data", "Upsert operation", "Creates table", "Reads data"], correct: 1, category: "Delta Lake", level: 7 },
    { question: "Delta format stores data as?", options: ["JSON", "CSV", "Parquet", "Avro"], correct: 2, category: "Delta Lake", level: 7 },
    // Delta Lake Advanced
    { question: "What is Time Travel?", options: ["Query history", "Data versioning", "Faster processing", "Schema migration"], correct: 1, category: "Delta Lake", level: 8 },
    { question: "VACUUM removes?", options: ["Duplicates", "Old files", "Null values", "Indexes"], correct: 1, category: "Delta Lake", level: 8 },
    { question: "OPTIMIZE does?", options: ["Indexes data", "Compacts files", "Caches data", "Drops partitions"], correct: 1, category: "Delta Lake", level: 8 },
    { question: "Z-ORDER improves?", options: ["Write speed", "Read filtering", "Compression", "Schema evolution"], correct: 1, category: "Delta Lake", level: 8 },
    { question: "Delta Lake transaction log is?", options: ["_metadata/", "_delta_log/", "_transactions/", "_log/"], correct: 1, category: "Delta Lake", level: 8 }
];

// ==========================================
// MEMORY GAME DATA - EXPANDED
// ==========================================

const memoryPairs = [
    // SQL Concepts
    { term: "SELECT", definition: "Retrieves data" },
    { term: "WHERE", definition: "Filters rows" },
    { term: "GROUP BY", definition: "Aggregates data" },
    { term: "JOIN", definition: "Combines tables" },
    { term: "ORDER BY", definition: "Sorts results" },
    { term: "HAVING", definition: "Filters groups" },
    { term: "COUNT(*)", definition: "Counts rows" },
    { term: "AVG()", definition: "Calculates mean" },
    { term: "DISTINCT", definition: "Removes duplicates" },
    { term: "UNION", definition: "Combines results" },
    { term: "INNER JOIN", definition: "Matching rows only" },
    { term: "LEFT JOIN", definition: "All left + matches" },
    // PySpark Concepts
    { term: ".filter()", definition: "Row filtering" },
    { term: ".select()", definition: "Column selection" },
    { term: ".groupBy()", definition: "Grouping data" },
    { term: ".withColumn()", definition: "Add/modify column" },
    { term: ".show()", definition: "Display results" },
    { term: ".collect()", definition: "Gather to driver" },
    { term: ".cache()", definition: "Store in memory" },
    { term: ".repartition()", definition: "Redistribute data" },
    // Delta Lake Concepts
    { term: "MERGE", definition: "Upsert data" },
    { term: "VACUUM", definition: "Clean old files" },
    { term: "OPTIMIZE", definition: "Compact files" },
    { term: "Z-ORDER", definition: "Data clustering" },
    { term: "Time Travel", definition: "Query history" },
    { term: "_delta_log", definition: "Transaction log" }
];

// ==========================================
// INITIALIZATION
// ==========================================

function initGamesPage() {
    loadGameState();
    loadLearningProgress();
    updateUI();
    startDailyTimer();
    // Render Mini Map
    renderMiniMap();
}

function loadGameState() {
    const saved = localStorage.getItem('gameState');
    if (saved) {
        const state = JSON.parse(saved);
        // Don't overwrite config and calculated stats with old saved state
        const { gameUnlocks, learningStats, ...rest } = state;
        Object.assign(GameEngine, rest);
    }
}

function loadLearningProgress() {
    const saved = localStorage.getItem('learningProgress');
    if (saved) {
        const progress = JSON.parse(saved);

        // Calculate stats from saved unitsState
        if (progress.unitsState) {
            let units = 0;
            let skills = 0;
            let crowns = 0;

            progress.unitsState.forEach((unit, index) => {
                const unitSkills = unit.skills.length;
                const completedSkills = unit.skills.filter(s => s.crowns > 0).length; // Crown > 0 means completed at least level 1

                // If all skills have at least 1 crown, unit is "completed" for locking purposes
                if (completedSkills === unitSkills && unitSkills > 0) units++;

                skills += completedSkills;
                crowns += unit.skills.reduce((sum, s) => sum + s.crowns, 0);
            });

            GameEngine.learningStats = { units, skills, crowns };
        }
    }
}

function renderGameLocks() {
    // Locks removed by user request - all games accessible
    const gameCards = document.querySelectorAll('.game-card');
    gameCards.forEach(card => card.classList.remove('locked-game'));
    const overlays = document.querySelectorAll('.lock-overlay');
    overlays.forEach(o => o.remove());
}

function saveGameState() {
    localStorage.setItem('gameState', JSON.stringify(GameEngine));
}

function updateUI() {
    // Update lives
    const livesDisplay = document.getElementById('livesCount');
    if (livesDisplay) {
        livesDisplay.textContent = '❤️'.repeat(GameEngine.lives) + '🖤'.repeat(5 - GameEngine.lives);
    }

    // Update coins
    const coinsDisplay = document.getElementById('coinsCount');
    if (coinsDisplay) {
        coinsDisplay.textContent = GameEngine.coins;
    }

    // Update XP bar
    const xpFill = document.getElementById('xpFill');
    const levelDisplay = document.getElementById('playerLevel');
    const currentXPDisplay = document.getElementById('currentXP');

    if (xpFill) {
        const xpForLevel = 1000;
        const progress = (GameEngine.currentXP % xpForLevel) / xpForLevel * 100;
        xpFill.style.width = `${progress}%`;
    }

    if (levelDisplay) levelDisplay.textContent = GameEngine.level;
    if (currentXPDisplay) currentXPDisplay.textContent = GameEngine.currentXP % 1000;

    // Render Mini Map
    renderMiniMap();
}

function renderMiniMap() {
    const container = document.getElementById('miniLearningMap');
    if (!container) return;

    // Use learningUnits from global scope (loaded via learning-path.js)
    // If learningUnits not available, define fallback or check type
    const units = (typeof learningUnits !== 'undefined') ? learningUnits : [
        { id: 1, name: "SQL Foundations", icon: "📊" },
        { id: 2, name: "Aggregations", icon: "📈" },
        { id: 3, name: "Joins", icon: "🔗" },
        { id: 4, name: "PySpark", icon: "🐍" },
        { id: 5, name: "Delta Lake", icon: "🌊" }
    ];

    const currentUnitId = GameEngine.learningStats.units + 1; // Assuming units is completed count

    container.innerHTML = units.map((unit, index) => {
        // Determine status
        // units stats is "count of COMPLETED units".
        // So if units=0, current is 1. unit at index 0 (id 1) is current.
        // if units=1, unit 1 completed, unit 2 current.

        let status = 'locked';
        let statusIcon = '';

        if (index < GameEngine.learningStats.units) {
            status = 'completed';
            statusIcon = '✓';
        } else if (index === GameEngine.learningStats.units) {
            status = 'current';
            statusIcon = ''; // Current unit just shows normal icon
        } else {
            status = 'locked';
            statusIcon = '🔒';
        }

        return `
            <div class="map-node ${status}" title="${unit.name} - ${status}">
                <div class="node-circle">
                    ${status === 'locked' ? '🔒' : unit.icon}
                </div>
                <div class="node-label">
                    Unit ${unit.id}<br>${unit.name}
                </div>
            </div>
        `;
    }).join('');
}

// ==========================================
// GAME LAUNCHER
// ==========================================

function startGame(gameType) {
    // Locks removed - all games accessible immediately

    const modal = document.getElementById('gameModal');
    const content = document.getElementById('gameContent');

    if (!modal || !content) return;

    modal.classList.add('active');
    GameEngine.currentGame = gameType;
    GameEngine.gameScore = 0;

    switch (gameType) {
        case 'puzzle':
            startPuzzleGame(content);
            break;
        case 'quiz':
            startQuizBattle(content);
            break;
        case 'memory':
            startMemoryGame(content);
            break;
        case 'bugs':
            startBugHunter(content);
            break;
        case 'speed':
            startSpeedCoder(content);
            break;
        case 'boss':
            startBossBattle(content);
            break;
        case 'daily':
            startDailyChallenge(content);
            break;
        case 'flashcards':
            startFlashcards(content);
            break;
        case 'fillblanks':
            startFillBlanks(content);
            break;
        case 'querypredict':
            startQueryPredictor(content);
            break;
        case 'schemabuilder':
            startSchemaBuilder(content);
            break;
        case 'joinmaster':
            startJoinMaster(content);
            break;
        default:
            content.innerHTML = '<p>Game coming soon!</p>';
    }
}

function closeGame() {
    const modal = document.getElementById('gameModal');
    if (modal) {
        modal.classList.remove('active');
    }
    GameEngine.currentGame = null;
    updateUI();
    saveGameState();
}

// ==========================================
// PUZZLE GAME
// ==========================================

let currentPuzzle = 0;
let placedBlocks = [];

function startPuzzleGame(container) {
    currentPuzzle = 0;
    placedBlocks = [];
    renderPuzzle(container);
}

function renderPuzzle(container) {
    const puzzle = puzzleQuestions[currentPuzzle];

    container.innerHTML = `
        <button class="game-close-btn" onclick="closeGame()">✕</button>
        <div class="puzzle-game">
            <div class="puzzle-header">
                <h2>🧩 Code Puzzle</h2>
                <div class="puzzle-stats">
                    <div class="puzzle-stat">
                        <span>📝</span>
                        <span>${currentPuzzle + 1}/${puzzleQuestions.length}</span>
                    </div>
                    <div class="puzzle-stat">
                        <span>⭐</span>
                        <span>${GameEngine.gameScore} XP</span>
                    </div>
                    <div class="puzzle-stat">
                        <span>❤️</span>
                        <span>${GameEngine.lives}</span>
                    </div>
                </div>
            </div>
            
            <div class="puzzle-question">
                <h3>${puzzle.question}</h3>
                <p>${puzzle.description}</p>
                <span class="difficulty ${puzzle.difficulty}">${puzzle.difficulty.toUpperCase()}</span>
            </div>
            
            <div class="drop-zone" id="dropZone" ondrop="handleDrop(event)" ondragover="handleDragOver(event)" ondragleave="handleDragLeave(event)">
                <span class="drop-zone-placeholder" id="dropPlaceholder">Drag code blocks here to build your query...</span>
            </div>
            
            <div class="code-blocks" id="codeBlocks">
                ${shuffleArray([...puzzle.blocks]).map((block, i) => `
                    <div class="code-block ${getBlockClass(block)}" 
                         draggable="true" 
                         ondragstart="handleDragStart(event, '${block}')"
                         onclick="quickPlace('${block}')"
                         id="block-${i}">
                        ${block}
                    </div>
                `).join('')}
            </div>
            
            <div class="puzzle-actions">
                <button class="btn btn-ghost" onclick="resetPuzzle()">🔄 Reset</button>
                <button class="btn btn-ghost" onclick="useHint()">💡 Hint (${GameEngine.powerups.hints})</button>
                <button class="btn btn-primary" onclick="checkPuzzle()">✓ Check Answer</button>
            </div>
        </div>
    `;

    placedBlocks = [];
}

function getBlockClass(block) {
    const keywords = ['SELECT', 'FROM', 'WHERE', 'GROUP BY', 'ORDER BY', 'HAVING', 'JOIN', 'ON', 'AS'];
    const functions = ['COUNT(*)', 'SUM', 'AVG', 'MAX', 'MIN', '.filter', '.select', '.format', '.load', '.read'];
    const operators = ['>', '<', '=', '>=', '<=', '*', 'AND', 'OR'];

    if (keywords.includes(block)) return 'keyword';
    if (functions.some(f => block.includes(f))) return 'function';
    if (operators.includes(block)) return 'operator';
    return 'table';
}

function handleDragStart(event, block) {
    event.dataTransfer.setData('text/plain', block);
    event.target.classList.add('dragging');
}

function handleDragOver(event) {
    event.preventDefault();
    event.currentTarget.classList.add('drag-over');
}

function handleDragLeave(event) {
    event.currentTarget.classList.remove('drag-over');
}

function handleDrop(event) {
    event.preventDefault();
    event.currentTarget.classList.remove('drag-over');

    const block = event.dataTransfer.getData('text/plain');
    addBlockToDropZone(block);
}

function quickPlace(block) {
    addBlockToDropZone(block);
}

function addBlockToDropZone(block) {
    const dropZone = document.getElementById('dropZone');
    const placeholder = document.getElementById('dropPlaceholder');

    if (placeholder) placeholder.style.display = 'none';

    placedBlocks.push(block);

    const blockEl = document.createElement('div');
    blockEl.className = `code-block placed ${getBlockClass(block)}`;
    blockEl.textContent = block;
    blockEl.onclick = () => removeBlock(block, blockEl);

    dropZone.appendChild(blockEl);

    // Play sound
    if (window.GameEffects) {
        GameEffects.playSound('success');
    }
}

function removeBlock(block, element) {
    const index = placedBlocks.indexOf(block);
    if (index > -1) {
        placedBlocks.splice(index, 1);
    }
    element.remove();

    const dropZone = document.getElementById('dropZone');
    const placeholder = document.getElementById('dropPlaceholder');
    if (placedBlocks.length === 0 && placeholder) {
        placeholder.style.display = 'block';
    }
}

function resetPuzzle() {
    const container = document.getElementById('gameContent');
    renderPuzzle(container);
}

function checkPuzzle() {
    const puzzle = puzzleQuestions[currentPuzzle];
    const isCorrect = JSON.stringify(placedBlocks) === JSON.stringify(puzzle.correctOrder);

    if (isCorrect) {
        // Victory!
        GameEngine.gameScore += puzzle.xp;
        GameEngine.currentXP += puzzle.xp;
        GameEngine.coins += 10;

        if (window.GameEffects) {
            GameEffects.showXPPopup(puzzle.xp);
            GameEffects.createConfetti(30);
        }

        // Next puzzle or victory
        currentPuzzle++;
        if (currentPuzzle < puzzleQuestions.length) {
            setTimeout(() => {
                renderPuzzle(document.getElementById('gameContent'));
            }, 1500);
        } else {
            showVictory('puzzle');
        }
    } else {
        // Wrong answer
        GameEngine.lives--;

        if (window.GameEffects) {
            GameEffects.shakeElement(document.querySelector('.drop-zone'));
        }

        if (GameEngine.lives <= 0) {
            showDefeat();
        } else {
            showToast(`Wrong! ${GameEngine.lives} lives left`, 'error');
            updateUI();
        }
    }

    saveGameState();
}

function useHint() {
    if (GameEngine.powerups.hints <= 0) {
        showToast('No hints left! Buy more in the shop.', 'error');
        return;
    }

    GameEngine.powerups.hints--;
    const puzzle = puzzleQuestions[currentPuzzle];
    const nextBlock = puzzle.correctOrder[placedBlocks.length];

    if (nextBlock) {
        showToast(`Hint: Next block is "${nextBlock}"`, 'info');
    }

    saveGameState();
    updateUI();
}

// ==========================================
// QUIZ BATTLE GAME
// ==========================================

let quizIndex = 0;
let playerHP = 100;
let enemyHP = 100;
let quizTimer = null;
let timeLeft = 10;

function startQuizBattle(container) {
    quizIndex = 0;
    playerHP = 100;
    enemyHP = 100;
    renderQuizBattle(container);
}

function renderQuizBattle(container) {
    const question = quizQuestions[quizIndex];

    container.innerHTML = `
        <button class="game-close-btn" onclick="closeGame()">✕</button>
        <div class="quiz-battle">
            <div class="battle-arena">
                <div class="player-side">
                    <div class="player-avatar">🧙‍♂️</div>
                    <div class="health-bar">
                        <div class="health-fill" id="playerHealth" style="width: ${playerHP}%"></div>
                    </div>
                    <div class="health-text">You: ${playerHP} HP</div>
                </div>
                
                <div class="battle-vs">⚔️</div>
                
                <div class="enemy-side">
                    <div class="enemy-avatar" id="enemyAvatar">🐲</div>
                    <div class="health-bar">
                        <div class="health-fill" id="enemyHealth" style="width: ${enemyHP}%; background: linear-gradient(90deg, #ef4444, #f59e0b)"></div>
                    </div>
                    <div class="health-text">SQL Dragon: ${enemyHP} HP</div>
                </div>
            </div>
            
            <div class="battle-timer ${timeLeft <= 3 ? 'danger' : ''}" id="battleTimer">${timeLeft}</div>
            
            <div class="quiz-question-card">
                <h3>${question.question}</h3>
                <div class="quiz-options" id="quizOptions">
                    ${question.options.map((opt, i) => `
                        <div class="quiz-option" onclick="selectAnswer(${i})" id="option-${i}">
                            ${opt}
                        </div>
                    `).join('')}
                </div>
            </div>
        </div>
    `;

    startQuizTimer();
}

function startQuizTimer() {
    timeLeft = 10;
    updateTimerDisplay();

    quizTimer = setInterval(() => {
        timeLeft--;
        updateTimerDisplay();

        if (timeLeft <= 0) {
            clearInterval(quizTimer);
            selectAnswer(-1); // Time's up = wrong
        }
    }, 1000);
}

function updateTimerDisplay() {
    const timerEl = document.getElementById('battleTimer');
    if (timerEl) {
        timerEl.textContent = timeLeft;
        timerEl.className = `battle-timer ${timeLeft <= 3 ? 'danger' : ''}`;
    }
}

function selectAnswer(index) {
    clearInterval(quizTimer);

    const question = quizQuestions[quizIndex];
    const options = document.querySelectorAll('.quiz-option');

    // Disable all options
    options.forEach(opt => opt.style.pointerEvents = 'none');

    if (index === question.correct) {
        // Correct answer - attack enemy!
        options[index].classList.add('correct');

        const damage = 20 + (timeLeft * 2); // Bonus for speed
        enemyHP -= damage;

        document.getElementById('enemyHealth').style.width = `${Math.max(0, enemyHP)}%`;
        document.getElementById('enemyAvatar').style.animation = 'shake 0.5s ease';

        GameEngine.gameScore += 15;
        GameEngine.currentXP += 15;

        if (window.GameEffects) {
            GameEffects.playSound('success');
            GameEffects.createParticles(window.innerWidth - 200, 200, '#22c55e', 10);
        }

    } else {
        // Wrong answer - take damage!
        if (index >= 0) options[index].classList.add('wrong');
        options[question.correct].classList.add('correct');

        playerHP -= 25;
        document.getElementById('playerHealth').style.width = `${Math.max(0, playerHP)}%`;

        if (window.GameEffects) {
            GameEffects.playSound('error');
            GameEffects.shakeElement(document.querySelector('.player-side'));
        }
    }

    // Check win/lose
    setTimeout(() => {
        if (enemyHP <= 0) {
            showVictory('quiz');
        } else if (playerHP <= 0) {
            showDefeat();
        } else {
            quizIndex++;
            if (quizIndex >= quizQuestions.length) {
                quizIndex = 0; // Loop questions
            }
            renderQuizBattle(document.getElementById('gameContent'));
        }
    }, 1500);

    saveGameState();
}

// ==========================================
// MEMORY GAME
// ==========================================

let memoryCards = [];
let flippedCards = [];
let matchedPairs = 0;
let memoryMoves = 0;

function startMemoryGame(container) {
    matchedPairs = 0;
    memoryMoves = 0;
    flippedCards = [];

    // Create card pairs
    memoryCards = [];
    memoryPairs.slice(0, 6).forEach((pair, i) => {
        memoryCards.push({ id: i * 2, type: 'term', value: pair.term, pairId: i });
        memoryCards.push({ id: i * 2 + 1, type: 'def', value: pair.definition, pairId: i });
    });

    // Shuffle
    memoryCards = shuffleArray(memoryCards);

    renderMemoryGame(container);
}

function renderMemoryGame(container) {
    container.innerHTML = `
        <button class="game-close-btn" onclick="closeGame()">✕</button>
        <div class="memory-game">
            <div class="puzzle-header">
                <h2>🃏 Memory Match</h2>
                <div class="puzzle-stats">
                    <div class="puzzle-stat">
                        <span>🎯</span>
                        <span id="matchCount">${matchedPairs}/${memoryPairs.length > 6 ? 6 : memoryPairs.length}</span>
                    </div>
                    <div class="puzzle-stat">
                        <span>👆</span>
                        <span id="moveCount">${memoryMoves} moves</span>
                    </div>
                </div>
            </div>
            
            <p style="text-align: center; color: var(--text-secondary); margin-bottom: var(--spacing-xl)">
                Match SQL commands with their descriptions!
            </p>
            
            <div class="memory-grid" id="memoryGrid">
                ${memoryCards.map(card => `
                    <div class="memory-card" id="card-${card.id}" onclick="flipCard(${card.id})">
                        <div class="memory-card-inner">
                            <div class="memory-card-front">❓</div>
                            <div class="memory-card-back">${card.value}</div>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

function flipCard(cardId) {
    if (flippedCards.length >= 2) return;

    const cardEl = document.getElementById(`card-${cardId}`);
    if (!cardEl || cardEl.classList.contains('flipped') || cardEl.classList.contains('matched')) return;

    cardEl.classList.add('flipped');
    flippedCards.push(cardId);

    if (window.GameEffects) {
        GameEffects.playSound('success');
    }

    if (flippedCards.length === 2) {
        memoryMoves++;
        document.getElementById('moveCount').textContent = `${memoryMoves} moves`;

        const card1 = memoryCards.find(c => c.id === flippedCards[0]);
        const card2 = memoryCards.find(c => c.id === flippedCards[1]);

        if (card1.pairId === card2.pairId) {
            // Match!
            setTimeout(() => {
                document.getElementById(`card-${card1.id}`).classList.add('matched');
                document.getElementById(`card-${card2.id}`).classList.add('matched');

                matchedPairs++;
                document.getElementById('matchCount').textContent = `${matchedPairs}/6`;

                GameEngine.currentXP += 10;
                GameEngine.coins += 5;

                if (window.GameEffects) {
                    GameEffects.createParticles(window.innerWidth / 2, window.innerHeight / 2, '#22c55e', 10);
                }

                flippedCards = [];

                if (matchedPairs === 6) {
                    showVictory('memory');
                }
            }, 500);
        } else {
            // No match
            setTimeout(() => {
                document.getElementById(`card-${flippedCards[0]}`).classList.remove('flipped');
                document.getElementById(`card-${flippedCards[1]}`).classList.remove('flipped');
                flippedCards = [];
            }, 1000);
        }
    }

    saveGameState();
}

// ==========================================
// DAILY CHALLENGE
// ==========================================

function startDailyChallenge(container) {
    // Daily is a timed puzzle rush
    currentPuzzle = 0;
    placedBlocks = [];
    let dailyTimeLeft = 180; // 3 minutes
    let dailyScore = 0;

    const dailyTimer = setInterval(() => {
        dailyTimeLeft--;
        const minutes = Math.floor(dailyTimeLeft / 60);
        const seconds = dailyTimeLeft % 60;
        const timerEl = document.getElementById('dailyTimeLeft');
        if (timerEl) {
            timerEl.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
        }

        if (dailyTimeLeft <= 0) {
            clearInterval(dailyTimer);
            showVictory('daily', dailyScore);
        }
    }, 1000);

    container.innerHTML = `
        <button class="game-close-btn" onclick="closeGame()">✕</button>
        <div class="puzzle-game">
            <div class="puzzle-header">
                <h2>🎯 Daily Challenge - Speed Run!</h2>
                <div class="puzzle-stats">
                    <div class="puzzle-stat" style="background: linear-gradient(135deg, rgba(239, 68, 68, 0.2), rgba(245, 158, 11, 0.2))">
                        <span>⏱️</span>
                        <span id="dailyTimeLeft">3:00</span>
                    </div>
                    <div class="puzzle-stat">
                        <span>⭐</span>
                        <span id="dailyScore">0 pts</span>
                    </div>
                </div>
            </div>
            <p style="text-align: center; color: var(--text-secondary)">
                Complete as many puzzles as possible in 3 minutes!
            </p>
        </div>
    `;

    setTimeout(() => renderPuzzle(container), 100);
}

// ==========================================
// BUG HUNTER GAME
// ==========================================

const buggyCode = [
    {
        code: "SELEC * FROM employees WHERE salary > 50000",
        bug: "SELEC",
        fix: "SELECT",
        hint: "Check the first keyword spelling",
        category: "SQL",
        xp: 30
    },
    {
        code: "SELECT * FORM employees",
        bug: "FORM",
        fix: "FROM",
        hint: "Where does data come FROM?",
        category: "SQL",
        xp: 25
    },
    {
        code: "SELECT * FROM employees WERE salary > 1000",
        bug: "WERE",
        fix: "WHERE",
        hint: "Conditional filtering keyword is misspelled",
        category: "SQL",
        xp: 25
    },
    {
        code: "df.filtr(col('age') > 25)",
        bug: "filtr",
        fix: "filter",
        hint: "PySpark method name is incomplete",
        category: "PySpark",
        xp: 35
    },
    {
        code: "spark.read.formt('delta').load('/path')",
        bug: "formt",
        fix: "format",
        hint: "Check the format method spelling",
        category: "Delta Lake",
        xp: 35
    },
    {
        code: "SELECT COUNT(*) FROM orders GRUOP BY status",
        bug: "GRUOP",
        fix: "GROUP",
        hint: "Aggregation keyword has letters swapped",
        category: "SQL",
        xp: 30
    },
    {
        code: "df.withColum('new_col', lit(1))",
        bug: "withColum",
        fix: "withColumn",
        hint: "Missing a letter in the method name",
        category: "PySpark",
        xp: 35
    },
    {
        code: "SELECT name, AVGE(salary) FROM emp GROUP BY name",
        bug: "AVGE",
        fix: "AVG",
        hint: "Average function has extra letter",
        category: "SQL",
        xp: 30
    }
];

let currentBug = 0;
let bugsFound = 0;

function startBugHunter(container) {
    currentBug = 0;
    bugsFound = 0;
    renderBugHunter(container);
}

function renderBugHunter(container) {
    const bug = buggyCode[currentBug];

    container.innerHTML = `
        <button class="game-close-btn" onclick="closeGame()">✕</button>
        <div class="puzzle-game">
            <div class="puzzle-header">
                <h2>🐛 Bug Hunter</h2>
                <div class="puzzle-stats">
                    <div class="puzzle-stat">
                        <span>🔍</span>
                        <span>${currentBug + 1}/${buggyCode.length}</span>
                    </div>
                    <div class="puzzle-stat">
                        <span>🐛</span>
                        <span>${bugsFound} found</span>
                    </div>
                    <div class="puzzle-stat">
                        <span>❤️</span>
                        <span>${GameEngine.lives}</span>
                    </div>
                </div>
            </div>
            
            <div class="puzzle-question">
                <h3>Find the bug in this ${bug.category} code!</h3>
                <p>Click on the word that contains the error</p>
            </div>
            
            <div class="bug-code-display" id="bugCodeDisplay">
                ${bug.code.split(/(\s+)/).map((word, i) =>
        word.trim() ? `<span class="code-word" onclick="checkBug('${word}', ${i})" id="word-${i}">${word}</span>` : word
    ).join('')}
            </div>
            
            <div class="puzzle-actions">
                <button class="btn btn-ghost" onclick="showBugHint()">💡 Hint</button>
            </div>
        </div>
    `;
}

function checkBug(word, index) {
    const bug = buggyCode[currentBug];
    const wordEl = document.getElementById(`word-${index}`);

    if (word === bug.bug) {
        // Found the bug!
        wordEl.classList.add('bug-found');
        bugsFound++;
        GameEngine.gameScore += bug.xp;
        GameEngine.currentXP += bug.xp;
        GameEngine.coins += 15;

        if (window.GameEffects) {
            GameEffects.showXPPopup(bug.xp);
            GameEffects.createParticles(window.innerWidth / 2, 300, '#22c55e', 15);
        }

        showToast(`Bug found! Should be "${bug.fix}"`, 'success');

        setTimeout(() => {
            currentBug++;
            if (currentBug < buggyCode.length) {
                renderBugHunter(document.getElementById('gameContent'));
            } else {
                showVictory('bugs');
            }
        }, 1500);
    } else {
        // Wrong click
        wordEl.classList.add('wrong-word');
        GameEngine.lives--;

        if (window.GameEffects) {
            GameEffects.shakeElement(wordEl);
        }

        if (GameEngine.lives <= 0) {
            showDefeat();
        } else {
            showToast(`Not the bug! ${GameEngine.lives} lives left`, 'error');
        }

        setTimeout(() => wordEl.classList.remove('wrong-word'), 500);
    }

    saveGameState();
}

function showBugHint() {
    const bug = buggyCode[currentBug];
    showToast(`💡 ${bug.hint}`, 'info');
}

// ==========================================
// SPEED CODER GAME
// ==========================================

const speedWords = [
    'SELECT', 'FROM', 'WHERE', 'GROUP BY', 'ORDER BY', 'JOIN', 'LEFT', 'RIGHT',
    'INNER', 'COUNT', 'SUM', 'AVG', 'MAX', 'MIN', 'HAVING', 'DISTINCT', 'AS',
    'AND', 'OR', 'NOT', 'IN', 'BETWEEN', 'LIKE', 'NULL', 'INSERT', 'UPDATE',
    'DELETE', 'CREATE', 'TABLE', 'INDEX', 'VIEW', 'MERGE', 'UNION', 'EXCEPT',
    'spark', 'filter', 'select', 'groupBy', 'agg', 'withColumn', 'join',
    'read', 'write', 'format', 'delta', 'parquet', 'csv', 'json', 'load'
];

let speedScore = 0;
let speedTimeLeft = 60;
let speedTimer = null;
let fallingWords = [];
let speedGameActive = false;

function startSpeedCoder(container) {
    speedScore = 0;
    speedTimeLeft = 60;
    fallingWords = [];
    speedGameActive = true;

    container.innerHTML = `
        <button class="game-close-btn" onclick="closeSpeedGame()">✕</button>
        <div class="speed-game">
            <div class="puzzle-header">
                <h2>⚡ Speed Coder</h2>
                <div class="puzzle-stats">
                    <div class="puzzle-stat">
                        <span>⏱️</span>
                        <span id="speedTimeLeft">${speedTimeLeft}s</span>
                    </div>
                    <div class="puzzle-stat">
                        <span>⭐</span>
                        <span id="speedScore">${speedScore}</span>
                    </div>
                </div>
            </div>
            
            <p style="text-align: center; color: var(--text-secondary); margin-bottom: 1rem;">
                Type the falling keywords before they reach the bottom!
            </p>
            
            <div class="speed-arena" id="speedArena"></div>
            
            <div class="speed-input-container">
                <input type="text" id="speedInput" class="speed-input" placeholder="Type here..." autofocus onkeyup="checkSpeedInput(event)">
            </div>
        </div>
    `;

    // Start game loop
    speedTimer = setInterval(speedGameLoop, 50);

    // Spawn words
    spawnWord();
    setInterval(() => {
        if (speedGameActive) spawnWord();
    }, 2000);

    // Countdown
    const countdownTimer = setInterval(() => {
        speedTimeLeft--;
        document.getElementById('speedTimeLeft').textContent = `${speedTimeLeft}s`;

        if (speedTimeLeft <= 0) {
            clearInterval(countdownTimer);
            endSpeedGame();
        }
    }, 1000);
}

function spawnWord() {
    const arena = document.getElementById('speedArena');
    if (!arena) return;

    const word = speedWords[Math.floor(Math.random() * speedWords.length)];
    const wordEl = document.createElement('div');
    wordEl.className = 'falling-word';
    wordEl.textContent = word;
    wordEl.dataset.word = word.toLowerCase();
    wordEl.style.left = `${Math.random() * 80 + 10}%`;
    wordEl.style.top = '0px';

    arena.appendChild(wordEl);
    fallingWords.push({ element: wordEl, word: word.toLowerCase(), y: 0 });
}

function speedGameLoop() {
    if (!speedGameActive) return;

    const arena = document.getElementById('speedArena');
    if (!arena) return;

    const arenaHeight = arena.offsetHeight;

    fallingWords = fallingWords.filter(fw => {
        fw.y += 1.5;
        fw.element.style.top = `${fw.y}px`;

        if (fw.y > arenaHeight - 30) {
            // Word hit bottom - lose life
            fw.element.remove();
            GameEngine.lives--;

            if (GameEngine.lives <= 0) {
                endSpeedGame();
                showDefeat();
            }

            return false;
        }
        return true;
    });
}

function checkSpeedInput(event) {
    const input = document.getElementById('speedInput');
    const typed = input.value.toLowerCase().trim();

    const matchIndex = fallingWords.findIndex(fw => fw.word === typed);

    if (matchIndex !== -1) {
        const matched = fallingWords[matchIndex];
        matched.element.classList.add('word-caught');

        setTimeout(() => matched.element.remove(), 200);
        fallingWords.splice(matchIndex, 1);

        speedScore += 10;
        GameEngine.currentXP += 5;
        GameEngine.coins += 2;

        document.getElementById('speedScore').textContent = speedScore;
        input.value = '';

        if (window.GameEffects) {
            GameEffects.playSound('success');
        }
    }
}

function closeSpeedGame() {
    speedGameActive = false;
    clearInterval(speedTimer);
    closeGame();
}

function endSpeedGame() {
    speedGameActive = false;
    clearInterval(speedTimer);
    GameEngine.gameScore = speedScore;
    showVictory('speed');
}

// ==========================================
// BOSS BATTLE GAME
// ==========================================

const bossQuestions = [
    { q: "Complete: SELECT * ___ employees", a: "FROM", category: "SQL" },
    { q: "Complete: WHERE salary ___ 50000", a: ">", category: "SQL" },
    { q: "Aggregate function to count rows?", a: "COUNT", category: "SQL" },
    { q: "PySpark method to filter: df.___", a: "filter", category: "PySpark" },
    { q: "Delta Lake format name?", a: "delta", category: "Delta Lake" },
    { q: "Sort results with ORDER ___", a: "BY", category: "SQL" },
    { q: "ACID stands for: Atomicity, Consistency, Isolation, ___", a: "Durability", category: "Delta Lake" },
    { q: "PySpark: df.groupBy().___() for aggregation", a: "agg", category: "PySpark" },
    { q: "Keyword to combine tables?", a: "JOIN", category: "SQL" },
    { q: "Delta time travel uses ___ keyword", a: "VERSION", category: "Delta Lake" }
];

let bossHP = 100;
let bossPlayerHP = 100;
let bossQuestionIndex = 0;
let bossTimer = null;
let bossTimeLeft = 15;

function startBossBattle(container) {
    bossHP = 100;
    bossPlayerHP = 100;
    bossQuestionIndex = 0;
    renderBossBattle(container);
}

function renderBossBattle(container) {
    const question = bossQuestions[bossQuestionIndex];

    container.innerHTML = `
        <button class="game-close-btn" onclick="closeGame()">✕</button>
        <div class="boss-battle">
            <div class="boss-arena">
                <div class="boss-enemy">
                    <div class="boss-avatar">🐉</div>
                    <div class="boss-name">Delta Dragon</div>
                    <div class="health-bar boss-health">
                        <div class="health-fill" id="bossHP" style="width: ${bossHP}%; background: linear-gradient(90deg, #dc2626, #f97316)"></div>
                    </div>
                    <div class="health-text">${bossHP} HP</div>
                </div>
                
                <div class="boss-player">
                    <div class="player-avatar">🧙‍♂️</div>
                    <div class="health-bar">
                        <div class="health-fill" id="bossPlayerHP" style="width: ${bossPlayerHP}%"></div>
                    </div>
                    <div class="health-text">${bossPlayerHP} HP</div>
                </div>
            </div>
            
            <div class="boss-timer" id="bossTimer">${bossTimeLeft}</div>
            
            <div class="boss-question">
                <span class="boss-category">${question.category}</span>
                <h3>${question.q}</h3>
                <input type="text" id="bossAnswer" class="boss-input" placeholder="Type your answer..." autofocus onkeyup="checkBossAnswer(event)">
            </div>
            
            <button class="btn btn-primary" onclick="submitBossAnswer()">⚔️ Attack!</button>
        </div>
    `;

    startBossTimer();
}

function startBossTimer() {
    bossTimeLeft = 15;
    updateBossTimer();

    bossTimer = setInterval(() => {
        bossTimeLeft--;
        updateBossTimer();

        if (bossTimeLeft <= 0) {
            clearInterval(bossTimer);
            bossPlayerTakeDamage();
        }
    }, 1000);
}

function updateBossTimer() {
    const timer = document.getElementById('bossTimer');
    if (timer) {
        timer.textContent = bossTimeLeft;
        timer.style.color = bossTimeLeft <= 5 ? '#ef4444' : '#fbbf24';
    }
}

function checkBossAnswer(event) {
    if (event.key === 'Enter') {
        submitBossAnswer();
    }
}

function submitBossAnswer() {
    clearInterval(bossTimer);

    const input = document.getElementById('bossAnswer');
    const answer = input.value.trim().toUpperCase();
    const correct = bossQuestions[bossQuestionIndex].a.toUpperCase();

    if (answer === correct) {
        // Hit the boss!
        const damage = 15 + bossTimeLeft;
        bossHP -= damage;
        document.getElementById('bossHP').style.width = `${Math.max(0, bossHP)}%`;

        GameEngine.gameScore += 20;
        GameEngine.currentXP += 20;

        if (window.GameEffects) {
            GameEffects.playSound('success');
            GameEffects.createParticles(window.innerWidth / 2, 150, '#22c55e', 20);
        }

        showToast(`Critical hit! -${damage} damage!`, 'success');

        if (bossHP <= 0) {
            GameEngine.coins += 100;
            showVictory('boss');
            return;
        }
    } else {
        bossPlayerTakeDamage();
        return;
    }

    // Next question
    bossQuestionIndex = (bossQuestionIndex + 1) % bossQuestions.length;
    setTimeout(() => renderBossBattle(document.getElementById('gameContent')), 1000);
    saveGameState();
}

function bossPlayerTakeDamage() {
    bossPlayerHP -= 20;
    document.getElementById('bossPlayerHP').style.width = `${Math.max(0, bossPlayerHP)}%`;

    if (window.GameEffects) {
        GameEffects.playSound('error');
        GameEffects.shakeElement(document.querySelector('.boss-player'));
    }

    showToast('The dragon attacks! -20 HP', 'error');

    if (bossPlayerHP <= 0) {
        showDefeat();
        return;
    }

    bossQuestionIndex = (bossQuestionIndex + 1) % bossQuestions.length;
    setTimeout(() => renderBossBattle(document.getElementById('gameContent')), 1000);
}

// ==========================================
// FLASHCARDS GAME
// ==========================================

const flashcards = [
    { front: "SELECT", back: "Retrieves specific columns from a table", category: "SQL" },
    { front: "WHERE", back: "Filters rows based on a condition", category: "SQL" },
    { front: "GROUP BY", back: "Groups rows for aggregate functions", category: "SQL" },
    { front: "JOIN", back: "Combines rows from two or more tables", category: "SQL" },
    { front: "HAVING", back: "Filters groups after aggregation", category: "SQL" },
    { front: ".filter()", back: "PySpark method to filter DataFrame rows", category: "PySpark" },
    { front: ".select()", back: "PySpark method to select columns", category: "PySpark" },
    { front: ".groupBy()", back: "PySpark method for grouping data", category: "PySpark" },
    { front: "MERGE", back: "Delta Lake upsert operation", category: "Delta Lake" },
    { front: "Time Travel", back: "Query historical versions of Delta table", category: "Delta Lake" },
    { front: "ACID", back: "Atomicity, Consistency, Isolation, Durability", category: "Delta Lake" },
    { front: "VACUUM", back: "Removes old files from Delta table", category: "Delta Lake" }
];

let flashcardIndex = 0;
let flashcardFlipped = false;
let flashcardsKnown = 0;

function startFlashcards(container) {
    flashcardIndex = 0;
    flashcardsKnown = 0;
    renderFlashcard(container);
}

function renderFlashcard(container) {
    const card = flashcards[flashcardIndex];

    container.innerHTML = `
        <button class="game-close-btn" onclick="closeGame()">✕</button>
        <div class="flashcard-game">
            <div class="puzzle-header">
                <h2>📚 Flashcards</h2>
                <div class="puzzle-stats">
                    <div class="puzzle-stat">
                        <span>📝</span>
                        <span>${flashcardIndex + 1}/${flashcards.length}</span>
                    </div>
                    <div class="puzzle-stat">
                        <span>✅</span>
                        <span>${flashcardsKnown} known</span>
                    </div>
                </div>
            </div>
            
            <div class="flashcard" id="flashcard" onclick="flipFlashcard()">
                <div class="flashcard-inner ${flashcardFlipped ? 'flipped' : ''}">
                    <div class="flashcard-front">
                        <span class="flashcard-category">${card.category}</span>
                        <h3>${card.front}</h3>
                        <p>Tap to reveal</p>
                    </div>
                    <div class="flashcard-back">
                        <p>${card.back}</p>
                    </div>
                </div>
            </div>
            
            <div class="flashcard-actions">
                <button class="btn btn-error" onclick="flashcardResponse(false)">❌ Still Learning</button>
                <button class="btn btn-success" onclick="flashcardResponse(true)">✅ Got It!</button>
            </div>
        </div>
    `;
    flashcardFlipped = false;
}

function flipFlashcard() {
    flashcardFlipped = !flashcardFlipped;
    document.querySelector('.flashcard-inner').classList.toggle('flipped');

    if (window.GameEffects) {
        GameEffects.playSound('success');
    }
}

function flashcardResponse(knew) {
    if (knew) {
        flashcardsKnown++;
        GameEngine.currentXP += 5;
        GameEngine.coins += 2;
    }

    flashcardIndex++;

    if (flashcardIndex >= flashcards.length) {
        GameEngine.gameScore = flashcardsKnown * 10;
        showVictory('flashcards');
    } else {
        renderFlashcard(document.getElementById('gameContent'));
    }

    saveGameState();
}

// ==========================================
// FILL IN THE BLANKS GAME
// ==========================================

const fillBlanksQuestions = [
    { sentence: "SELECT * ___ employees WHERE salary > 50000", answer: "FROM", category: "SQL" },
    { sentence: "___ name, COUNT(*) FROM orders GROUP BY name", answer: "SELECT", category: "SQL" },
    { sentence: "df.filter(col('age') ___ 25)", answer: ">", category: "PySpark" },
    { sentence: "spark.read.format('___').load('/data')", answer: "delta", category: "Delta Lake" },
    { sentence: "SELECT * FROM orders ORDER ___ date DESC", answer: "BY", category: "SQL" },
    { sentence: "df.___('new_col', lit(100))", answer: "withColumn", category: "PySpark" },
    { sentence: "MERGE INTO target ___ source ON condition", answer: "USING", category: "Delta Lake" },
    { sentence: "SELECT DISTINCT ___ FROM customers", answer: "name", category: "SQL" }
];

let fillBlanksIndex = 0;
let fillBlanksCorrect = 0;

function startFillBlanks(container) {
    fillBlanksIndex = 0;
    fillBlanksCorrect = 0;
    renderFillBlanks(container);
}

function renderFillBlanks(container) {
    const q = fillBlanksQuestions[fillBlanksIndex];

    container.innerHTML = `
        <button class="game-close-btn" onclick="closeGame()">✕</button>
        <div class="fillblanks-game">
            <div class="puzzle-header">
                <h2>✏️ Fill in the Blanks</h2>
                <div class="puzzle-stats">
                    <div class="puzzle-stat">
                        <span>📝</span>
                        <span>${fillBlanksIndex + 1}/${fillBlanksQuestions.length}</span>
                    </div>
                    <div class="puzzle-stat">
                        <span>✅</span>
                        <span>${fillBlanksCorrect} correct</span>
                    </div>
                    <div class="puzzle-stat">
                        <span>❤️</span>
                        <span>${GameEngine.lives}</span>
                    </div>
                </div>
            </div>
            
            <div class="fillblanks-question">
                <span class="question-category">${q.category}</span>
                <div class="code-sentence">
                    ${q.sentence.replace('___', '<span class="blank-space">____</span>')}
                </div>
            </div>
            
            <div class="fillblanks-input">
                <input type="text" id="fillAnswer" class="fill-input" placeholder="Type the missing word..." autofocus onkeyup="checkFillAnswer(event)">
                <button class="btn btn-primary" onclick="submitFillAnswer()">Check</button>
            </div>
        </div>
    `;
}

function checkFillAnswer(event) {
    if (event.key === 'Enter') {
        submitFillAnswer();
    }
}

function submitFillAnswer() {
    const input = document.getElementById('fillAnswer');
    const answer = input.value.trim().toUpperCase();
    const correct = fillBlanksQuestions[fillBlanksIndex].answer.toUpperCase();

    if (answer === correct) {
        fillBlanksCorrect++;
        GameEngine.gameScore += 25;
        GameEngine.currentXP += 25;
        GameEngine.coins += 10;

        if (window.GameEffects) {
            GameEffects.showXPPopup(25);
            GameEffects.createConfetti(20);
        }

        showToast('Correct!', 'success');
    } else {
        GameEngine.lives--;

        if (window.GameEffects) {
            GameEffects.shakeElement(document.querySelector('.fillblanks-question'));
        }

        showToast(`Wrong! Answer was "${fillBlanksQuestions[fillBlanksIndex].answer}"`, 'error');

        if (GameEngine.lives <= 0) {
            showDefeat();
            return;
        }
    }

    fillBlanksIndex++;

    if (fillBlanksIndex >= fillBlanksQuestions.length) {
        showVictory('fillblanks');
    } else {
        renderFillBlanks(document.getElementById('gameContent'));
    }

    saveGameState();
}

// ==========================================
// VICTORY / DEFEAT SCREENS
// ==========================================

function showVictory(gameType, bonusScore = 0) {
    const baseXP = GameEngine.gameScore + bonusScore;
    const coins = Math.floor(baseXP / 2);

    GameEngine.currentXP += baseXP;
    GameEngine.coins += coins;

    // Check level up
    const newLevel = Math.floor(GameEngine.currentXP / 1000) + 1;
    if (newLevel > GameEngine.level) {
        GameEngine.level = newLevel;
        if (window.GameEffects) {
            setTimeout(() => GameEffects.showLevelUp(newLevel), 2000);
        }
    }

    const container = document.getElementById('gameContent');
    container.innerHTML = `
        <div class="result-screen">
            <div class="result-icon">🏆</div>
            <h1 class="result-title victory">VICTORY!</h1>
            <p style="color: var(--text-secondary)">You crushed it!</p>
            
            <div class="result-rewards">
                <div class="reward-item">
                    <div class="reward-value">+${baseXP}</div>
                    <div class="reward-label">XP Earned</div>
                </div>
                <div class="reward-item">
                    <div class="reward-value">+${coins}</div>
                    <div class="reward-label">Coins</div>
                </div>
            </div>
            
            <div style="display: flex; gap: var(--spacing-md)">
                <button class="btn btn-ghost" onclick="closeGame()">Back to Games</button>
                <button class="btn btn-primary" onclick="startGame('${gameType}')">Play Again</button>
            </div>
        </div>
    `;

    if (window.GameEffects) {
        GameEffects.createConfetti(100);
        GameEffects.playSound('levelUp');
    }

    saveGameState();
}

function showDefeat() {
    const container = document.getElementById('gameContent');
    container.innerHTML = `
        <div class="result-screen">
            <div class="result-icon">💔</div>
            <h1 class="result-title defeat">GAME OVER</h1>
            <p style="color: var(--text-secondary)">Don't give up! Try again!</p>
            
            <div class="result-rewards">
                <div class="reward-item">
                    <div class="reward-value">${GameEngine.gameScore}</div>
                    <div class="reward-label">Score</div>
                </div>
            </div>
            
            <div style="display: flex; gap: var(--spacing-md)">
                <button class="btn btn-ghost" onclick="closeGame()">Back to Games</button>
                <button class="btn btn-primary" onclick="reviveWithCoins()">❤️ Revive (50 🪙)</button>
            </div>
        </div>
    `;

    if (window.GameEffects) {
        GameEffects.playSound('error');
    }
}

function reviveWithCoins() {
    if (GameEngine.coins >= 50) {
        GameEngine.coins -= 50;
        GameEngine.lives = 3;
        startGame(GameEngine.currentGame);
        showToast('Revived! Keep going!', 'success');
    } else {
        showToast('Not enough coins!', 'error');
    }
}

// ==========================================
// POWER-UPS
// ==========================================

function buyPowerup(type) {
    const prices = {
        hint: 50,
        skip: 100,
        life: 75,
        double: 150,
        freeze: 80
    };

    if (GameEngine.coins < prices[type]) {
        showToast('Not enough coins!', 'error');
        return;
    }

    GameEngine.coins -= prices[type];

    switch (type) {
        case 'hint':
            GameEngine.powerups.hints++;
            break;
        case 'skip':
            GameEngine.powerups.skips++;
            break;
        case 'life':
            GameEngine.lives = Math.min(5, GameEngine.lives + 1);
            break;
        case 'double':
            GameEngine.powerups.doubleXP = true;
            break;
        case 'freeze':
            GameEngine.powerups.freezes++;
            break;
    }

    showToast(`Purchased ${type}!`, 'success');
    updateUI();
    saveGameState();
}

// ==========================================
// UTILITIES
// ==========================================

function shuffleArray(array) {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
}

function startDailyTimer() {
    const timerEl = document.getElementById('dailyTimer');
    if (!timerEl) return;

    function updateTimer() {
        const now = new Date();
        const midnight = new Date(now);
        midnight.setHours(24, 0, 0, 0);

        const diff = midnight - now;
        const hours = Math.floor(diff / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((diff % (1000 * 60)) / 1000);

        timerEl.textContent = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }

    updateTimer();
    setInterval(updateTimer, 1000);
}

// ==========================================
// QUERY PREDICTOR GAME
// ==========================================

const queryPredictions = [
    {
        query: "SELECT COUNT(*) FROM orders WHERE status = 'pending'",
        question: "What does this query return?",
        options: ["All order details", "Number of pending orders", "Order IDs only", "Status values"],
        correct: 1,
        explanation: "COUNT(*) returns the number of rows matching the WHERE condition",
        xp: 30
    },
    {
        query: "SELECT name, MAX(salary) FROM employees GROUP BY department",
        question: "What's wrong with this query?",
        options: ["Nothing wrong", "Missing FROM", "name not in GROUP BY", "MAX is wrong"],
        correct: 2,
        explanation: "Non-aggregated columns must be in GROUP BY clause",
        xp: 40
    },
    {
        query: "SELECT * FROM orders o LEFT JOIN customers c ON o.customer_id = c.id",
        question: "How many rows if orders=100, customers=50, and 20 orders have no customer?",
        options: ["50", "80", "100", "150"],
        correct: 2,
        explanation: "LEFT JOIN keeps all left table rows (100 orders)",
        xp: 45
    },
    {
        query: "df.filter(col('age') > 30).select('name', 'age').count()",
        question: "What does this PySpark code return?",
        options: ["DataFrame", "List of names", "A number", "Error"],
        correct: 2,
        explanation: "count() returns the number of rows after filter",
        xp: 35
    },
    {
        query: "spark.read.format('delta').option('versionAsOf', 5).load('/data')",
        question: "What does this read?",
        options: ["Latest version", "Version 5 of Delta table", "5 random rows", "Schema only"],
        correct: 1,
        explanation: "Time Travel with versionAsOf reads historical version",
        xp: 40
    },
    {
        query: "SELECT DISTINCT department FROM employees ORDER BY department",
        question: "If there are 100 employees in 5 departments, how many rows returned?",
        options: ["100", "5", "1", "Error"],
        correct: 1,
        explanation: "DISTINCT removes duplicates, returning unique departments",
        xp: 25
    },
    {
        query: "df.groupBy('region').agg(sum('sales').alias('total_sales'))",
        question: "What column names will the result have?",
        options: ["region only", "sales only", "region, total_sales", "region, sum(sales)"],
        correct: 2,
        explanation: "alias() renames the aggregated column",
        xp: 35
    }
];

let queryPredictIndex = 0;
let queryCorrect = 0;

function startQueryPredictor(container) {
    queryPredictIndex = 0;
    queryCorrect = 0;
    renderQueryPredictor(container);
}

function renderQueryPredictor(container) {
    const q = queryPredictions[queryPredictIndex];

    container.innerHTML = `
        <button class="game-close-btn" onclick="closeGame()">✕</button>
        <div class="query-predictor">
            <div class="puzzle-header">
                <h2>🔮 Query Predictor</h2>
                <div class="puzzle-stats">
                    <div class="puzzle-stat">
                        <span>📝</span>
                        <span>${queryPredictIndex + 1}/${queryPredictions.length}</span>
                    </div>
                    <div class="puzzle-stat">
                        <span>✅</span>
                        <span>${queryCorrect} correct</span>
                    </div>
                    <div class="puzzle-stat">
                        <span>❤️</span>
                        <span>${GameEngine.lives}</span>
                    </div>
                </div>
            </div>
            
            <div class="query-display">
                <pre><code>${q.query}</code></pre>
            </div>
            
            <div class="query-question">
                <h3>${q.question}</h3>
            </div>
            
            <div class="query-options">
                ${q.options.map((opt, i) => `
                    <div class="query-option" onclick="selectQueryAnswer(${i})" id="qopt-${i}">
                        ${opt}
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

function selectQueryAnswer(index) {
    const q = queryPredictions[queryPredictIndex];
    const options = document.querySelectorAll('.query-option');

    options.forEach(opt => opt.style.pointerEvents = 'none');

    if (index === q.correct) {
        options[index].classList.add('correct');
        queryCorrect++;
        GameEngine.gameScore += q.xp;
        GameEngine.currentXP += q.xp;
        GameEngine.coins += 10;

        if (window.GameEffects) {
            GameEffects.showXPPopup(q.xp);
        }
    } else {
        options[index].classList.add('wrong');
        options[q.correct].classList.add('correct');
        GameEngine.lives--;

        if (GameEngine.lives <= 0) {
            setTimeout(() => showDefeat(), 1000);
            return;
        }
    }

    setTimeout(() => {
        queryPredictIndex++;
        if (queryPredictIndex < queryPredictions.length) {
            renderQueryPredictor(document.getElementById('gameContent'));
        } else {
            showVictory('querypredict');
        }
    }, 1500);

    saveGameState();
}

// ==========================================
// SCHEMA BUILDER GAME
// ==========================================

const schemaQuestions = [
    {
        task: "Create a table for storing customer orders",
        columns: ["order_id", "customer_name", "total_amount", "order_date", "status"],
        types: ["INT", "STRING", "DECIMAL", "DATE", "STRING"],
        hints: ["Primary key", "Customer's name", "Order total", "When ordered", "pending/shipped/delivered"],
        xp: 50
    },
    {
        task: "Design a table for employee records",
        columns: ["emp_id", "name", "department", "salary", "hire_date"],
        types: ["INT", "STRING", "STRING", "DECIMAL", "DATE"],
        hints: ["Unique ID", "Full name", "Dept name", "Annual salary", "Start date"],
        xp: 45
    },
    {
        task: "Build a table for product inventory",
        columns: ["product_id", "name", "category", "price", "quantity"],
        types: ["INT", "STRING", "STRING", "DECIMAL", "INT"],
        hints: ["SKU", "Product name", "Category", "Unit price", "Stock count"],
        xp: 45
    }
];

let schemaIndex = 0;
let schemaAssignments = {};

function startSchemaBuilder(container) {
    schemaIndex = 0;
    schemaAssignments = {};
    renderSchemaBuilder(container);
}

function renderSchemaBuilder(container) {
    const schema = schemaQuestions[schemaIndex];
    const typeOptions = ["INT", "STRING", "DECIMAL", "DATE", "BOOLEAN", "TIMESTAMP", "ARRAY", "MAP"];

    container.innerHTML = `
        <button class="game-close-btn" onclick="closeGame()">✕</button>
        <div class="schema-builder">
            <div class="puzzle-header">
                <h2>🏗️ Schema Builder</h2>
                <div class="puzzle-stats">
                    <div class="puzzle-stat">
                        <span>📝</span>
                        <span>${schemaIndex + 1}/${schemaQuestions.length}</span>
                    </div>
                </div>
            </div>
            
            <div class="schema-task">
                <h3>${schema.task}</h3>
                <p>Assign the correct data type to each column</p>
            </div>
            
            <div class="schema-columns">
                ${schema.columns.map((col, i) => `
                    <div class="schema-column">
                        <div class="column-info">
                            <span class="column-name">${col}</span>
                            <span class="column-hint">${schema.hints[i]}</span>
                        </div>
                        <select class="type-select" id="type-${i}" onchange="assignType(${i}, this.value)">
                            <option value="">Select type...</option>
                            ${typeOptions.map(t => `<option value="${t}">${t}</option>`).join('')}
                        </select>
                    </div>
                `).join('')}
            </div>
            
            <button class="btn btn-primary" onclick="checkSchema()">✓ Check Schema</button>
        </div>
    `;

    schemaAssignments = {};
}

function assignType(index, value) {
    schemaAssignments[index] = value;
}

function checkSchema() {
    const schema = schemaQuestions[schemaIndex];
    let allCorrect = true;

    schema.types.forEach((correctType, i) => {
        const select = document.getElementById(`type-${i}`);
        if (schemaAssignments[i] === correctType) {
            select.classList.add('correct');
        } else {
            select.classList.add('wrong');
            allCorrect = false;
        }
    });

    if (allCorrect) {
        GameEngine.gameScore += schema.xp;
        GameEngine.currentXP += schema.xp;
        GameEngine.coins += 20;

        if (window.GameEffects) {
            GameEffects.showXPPopup(schema.xp);
            GameEffects.createConfetti(30);
        }

        setTimeout(() => {
            schemaIndex++;
            if (schemaIndex < schemaQuestions.length) {
                renderSchemaBuilder(document.getElementById('gameContent'));
            } else {
                showVictory('schemabuilder');
            }
        }, 1500);
    } else {
        GameEngine.lives--;

        if (window.GameEffects) {
            GameEffects.shakeElement(document.querySelector('.schema-columns'));
        }

        if (GameEngine.lives <= 0) {
            showDefeat();
        } else {
            showToast(`Some types are wrong! ${GameEngine.lives} lives left`, 'error');
        }
    }

    saveGameState();
}

// ==========================================
// JOIN MASTER GAME
// ==========================================

const joinQuestions = [
    {
        scenario: "You have 'orders' (10 rows) and 'customers' (5 rows). Each order has a customer_id. 2 orders have customer_id that doesn't exist in customers.",
        question: "Using INNER JOIN orders ON customers, how many rows?",
        options: ["5", "8", "10", "15"],
        correct: 1,
        explanation: "INNER JOIN only returns matching rows: 10 - 2 = 8 orders with valid customers",
        visual: "INNER",
        xp: 40
    },
    {
        scenario: "Same tables: 'orders' (10 rows), 'customers' (5 rows). 2 orders have no matching customer.",
        question: "Using LEFT JOIN from orders to customers, how many rows?",
        options: ["5", "8", "10", "12"],
        correct: 2,
        explanation: "LEFT JOIN keeps all left table rows (10 orders), with NULL for non-matching customers",
        visual: "LEFT",
        xp: 40
    },
    {
        scenario: "Table A has [1,2,3], Table B has [2,3,4]. You need all values from both.",
        question: "Which JOIN type should you use?",
        options: ["INNER JOIN", "LEFT JOIN", "FULL OUTER JOIN", "CROSS JOIN"],
        correct: 2,
        explanation: "FULL OUTER JOIN returns all rows from both tables with NULLs where no match",
        visual: "FULL",
        xp: 45
    },
    {
        scenario: "You need every combination of products (3) and colors (4).",
        question: "Which JOIN produces 12 rows?",
        options: ["INNER JOIN", "LEFT JOIN", "RIGHT JOIN", "CROSS JOIN"],
        correct: 3,
        explanation: "CROSS JOIN produces Cartesian product: 3 × 4 = 12 rows",
        visual: "CROSS",
        xp: 50
    },
    {
        scenario: "Orders table has customer_id. Customers table has id. Some customers have no orders.",
        question: "To find customers who never ordered, use:",
        options: ["INNER JOIN", "LEFT JOIN + WHERE IS NULL", "RIGHT JOIN", "CROSS JOIN"],
        correct: 1,
        explanation: "LEFT JOIN from customers + WHERE orders.id IS NULL finds non-matching customers",
        visual: "ANTI",
        xp: 55
    }
];

let joinIndex = 0;
let joinCorrect = 0;

function startJoinMaster(container) {
    joinIndex = 0;
    joinCorrect = 0;
    renderJoinMaster(container);
}

function renderJoinMaster(container) {
    const q = joinQuestions[joinIndex];

    container.innerHTML = `
        <button class="game-close-btn" onclick="closeGame()">✕</button>
        <div class="join-master">
            <div class="puzzle-header">
                <h2>🔗 Join Master</h2>
                <div class="puzzle-stats">
                    <div class="puzzle-stat">
                        <span>📝</span>
                        <span>${joinIndex + 1}/${joinQuestions.length}</span>
                    </div>
                    <div class="puzzle-stat">
                        <span>✅</span>
                        <span>${joinCorrect} correct</span>
                    </div>
                    <div class="puzzle-stat">
                        <span>❤️</span>
                        <span>${GameEngine.lives}</span>
                    </div>
                </div>
            </div>
            
            <div class="join-visual">
                <div class="join-diagram ${q.visual.toLowerCase()}">
                    <div class="circle left">A</div>
                    <div class="circle right">B</div>
                </div>
            </div>
            
            <div class="join-scenario">
                <p>${q.scenario}</p>
            </div>
            
            <div class="join-question">
                <h3>${q.question}</h3>
            </div>
            
            <div class="join-options">
                ${q.options.map((opt, i) => `
                    <div class="join-option" onclick="selectJoinAnswer(${i})" id="jopt-${i}">
                        ${opt}
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

function selectJoinAnswer(index) {
    const q = joinQuestions[joinIndex];
    const options = document.querySelectorAll('.join-option');

    options.forEach(opt => opt.style.pointerEvents = 'none');

    if (index === q.correct) {
        options[index].classList.add('correct');
        joinCorrect++;
        GameEngine.gameScore += q.xp;
        GameEngine.currentXP += q.xp;
        GameEngine.coins += 15;

        if (window.GameEffects) {
            GameEffects.showXPPopup(q.xp);
        }

        showToast(q.explanation, 'success');
    } else {
        options[index].classList.add('wrong');
        options[q.correct].classList.add('correct');
        GameEngine.lives--;

        showToast(q.explanation, 'info');

        if (GameEngine.lives <= 0) {
            setTimeout(() => showDefeat(), 2000);
            return;
        }
    }

    setTimeout(() => {
        joinIndex++;
        if (joinIndex < joinQuestions.length) {
            renderJoinMaster(document.getElementById('gameContent'));
        } else {
            showVictory('joinmaster');
        }
    }, 2500);

    saveGameState();
}

// Make functions global
window.startGame = startGame;
window.closeGame = closeGame;
window.handleDragStart = handleDragStart;
window.handleDragOver = handleDragOver;
window.handleDragLeave = handleDragLeave;
window.handleDrop = handleDrop;
window.quickPlace = quickPlace;
window.checkPuzzle = checkPuzzle;
window.resetPuzzle = resetPuzzle;
window.useHint = useHint;
window.selectAnswer = selectAnswer;
window.flipCard = flipCard;
window.buyPowerup = buyPowerup;
window.reviveWithCoins = reviveWithCoins;
window.initGamesPage = initGamesPage;
window.checkBug = checkBug;
window.showBugHint = showBugHint;
window.checkSpeedInput = checkSpeedInput;
window.closeSpeedGame = closeSpeedGame;
window.checkBossAnswer = checkBossAnswer;
window.submitBossAnswer = submitBossAnswer;
window.flipFlashcard = flipFlashcard;
window.flashcardResponse = flashcardResponse;
window.checkFillAnswer = checkFillAnswer;
window.submitFillAnswer = submitFillAnswer;
window.selectQueryAnswer = selectQueryAnswer;
window.assignType = assignType;
window.checkSchema = checkSchema;
window.selectJoinAnswer = selectJoinAnswer;

