/**
 * Gamification System - Fun & Engaging Game Mechanics
 * XP, Levels, Achievements, Streaks, Combos, Daily Rewards
 */

// ==========================================
// GAMIFICATION STATE
// ==========================================

const GameState = {
    combo: 0,
    comboTimer: null,
    lastCorrectTime: null,
    dailyRewardClaimed: false,
    soundEnabled: true
};

// Sound effects (Web Audio API)
const AudioContext = window.AudioContext || window.webkitAudioContext;
let audioCtx = null;

function initAudio() {
    if (!audioCtx) {
        audioCtx = new AudioContext();
    }
}

function playSound(type) {
    if (!GameState.soundEnabled) return;
    initAudio();

    const oscillator = audioCtx.createOscillator();
    const gainNode = audioCtx.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioCtx.destination);

    const sounds = {
        success: { freq: 880, duration: 0.1, type: 'sine' },
        levelUp: { freq: 523.25, duration: 0.5, type: 'sine' },
        achievement: { freq: 659.25, duration: 0.3, type: 'triangle' },
        combo: { freq: 440 + (GameState.combo * 50), duration: 0.1, type: 'square' },
        error: { freq: 200, duration: 0.2, type: 'sawtooth' }
    };

    const sound = sounds[type] || sounds.success;
    oscillator.type = sound.type;
    oscillator.frequency.setValueAtTime(sound.freq, audioCtx.currentTime);
    gainNode.gain.setValueAtTime(0.1, audioCtx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + sound.duration);

    oscillator.start(audioCtx.currentTime);
    oscillator.stop(audioCtx.currentTime + sound.duration);
}

// ==========================================
// XP & POINTS ANIMATIONS
// ==========================================

/**
 * Show XP earned popup with animation
 */
function showXPPopup(points, bonusText = '') {
    const popup = document.createElement('div');
    popup.className = 'xp-popup';
    popup.innerHTML = `
        <div class="xp-value">+${points}</div>
        <div class="xp-label">XP EARNED ${bonusText}</div>
    `;
    document.body.appendChild(popup);

    playSound('success');
    createParticles(window.innerWidth / 2, window.innerHeight / 2, '#fbbf24', 10);

    setTimeout(() => popup.remove(), 2000);
}

/**
 * Create floating particles effect
 */
function createParticles(x, y, color, count = 10) {
    for (let i = 0; i < count; i++) {
        const particle = document.createElement('div');
        particle.className = 'particle';
        particle.style.cssText = `
            left: ${x}px;
            top: ${y}px;
            width: ${Math.random() * 10 + 5}px;
            height: ${Math.random() * 10 + 5}px;
            background: ${color};
            --tx: ${(Math.random() - 0.5) * 200}px;
            --ty: ${(Math.random() - 0.5) * 200}px;
        `;
        document.body.appendChild(particle);
        setTimeout(() => particle.remove(), 1000);
    }
}

/**
 * Create confetti celebration
 */
function createConfetti(count = 50) {
    const colors = ['#6366f1', '#8b5cf6', '#ec4899', '#fbbf24', '#22c55e', '#3b82f6'];

    for (let i = 0; i < count; i++) {
        setTimeout(() => {
            const confetti = document.createElement('div');
            confetti.className = 'confetti';
            confetti.style.cssText = `
                left: ${Math.random() * 100}%;
                background: ${colors[Math.floor(Math.random() * colors.length)]};
                animation-delay: ${Math.random() * 0.5}s;
                animation-duration: ${2 + Math.random() * 2}s;
            `;
            document.body.appendChild(confetti);
            setTimeout(() => confetti.remove(), 4000);
        }, i * 30);
    }
}

// ==========================================
// LEVEL UP CELEBRATION
// ==========================================

/**
 * Show epic level up celebration
 */
function showLevelUp(newLevel) {
    playSound('levelUp');
    createConfetti(100);

    const overlay = document.createElement('div');
    overlay.className = 'level-up-overlay';
    overlay.innerHTML = `
        <div class="level-up-content">
            <div class="level-up-icon">⭐</div>
            <div class="level-up-title">LEVEL UP!</div>
            <div class="level-up-level">${newLevel}</div>
            <div class="level-up-subtitle">Keep crushing those challenges!</div>
        </div>
    `;
    document.body.appendChild(overlay);

    // Play ascending tones
    setTimeout(() => playSound('levelUp'), 200);
    setTimeout(() => playSound('levelUp'), 400);

    overlay.addEventListener('click', () => {
        overlay.style.animation = 'fadeIn 0.3s ease reverse';
        setTimeout(() => overlay.remove(), 300);
    });

    setTimeout(() => {
        if (overlay.parentNode) {
            overlay.style.animation = 'fadeIn 0.3s ease reverse';
            setTimeout(() => overlay.remove(), 300);
        }
    }, 4000);
}

// ==========================================
// ACHIEVEMENT UNLOCKS
// ==========================================

/**
 * Show achievement unlock notification
 */
function showAchievementUnlock(badge) {
    playSound('achievement');

    const rarityClass = `rarity-${badge.rarity || 'common'}`;

    const notification = document.createElement('div');
    notification.className = 'achievement-unlock';
    notification.innerHTML = `
        <div class="achievement-header">
            <span>🏆</span>
            <span>Achievement Unlocked!</span>
        </div>
        <div class="achievement-body">
            <div class="achievement-icon">${badge.icon}</div>
            <div class="achievement-info">
                <h3>${badge.name}</h3>
                <p>${badge.description}</p>
                <span class="achievement-rarity ${rarityClass}">${badge.rarity || 'Common'}</span>
            </div>
        </div>
    `;
    document.body.appendChild(notification);

    createParticles(window.innerWidth - 180, 80, '#a855f7', 15);

    setTimeout(() => {
        notification.style.animation = 'achievementSlide 0.5s ease reverse';
        setTimeout(() => notification.remove(), 500);
    }, 5000);
}

// ==========================================
// COMBO SYSTEM
// ==========================================

/**
 * Increment combo for consecutive correct answers
 */
function incrementCombo() {
    GameState.combo++;
    playSound('combo');
    showComboCounter();

    // Reset combo after 30 seconds of inactivity
    if (GameState.comboTimer) {
        clearTimeout(GameState.comboTimer);
    }
    GameState.comboTimer = setTimeout(() => {
        resetCombo();
    }, 30000);
}

/**
 * Reset combo counter
 */
function resetCombo() {
    GameState.combo = 0;
    hideComboCounter();
}

/**
 * Show combo counter UI
 */
function showComboCounter() {
    let counter = document.querySelector('.combo-counter');

    if (!counter) {
        counter = document.createElement('div');
        counter.className = 'combo-counter';
        document.body.appendChild(counter);
    }

    const multiplier = 1 + (GameState.combo * 0.1);
    counter.innerHTML = `
        <div class="combo-label">🔥 COMBO</div>
        <div class="combo-value">x${GameState.combo}</div>
        <div class="combo-multiplier">+${Math.round((multiplier - 1) * 100)}% bonus XP</div>
    `;

    // Re-trigger animation
    counter.style.animation = 'none';
    counter.offsetHeight; // Trigger reflow
    counter.style.animation = 'comboAppear 0.3s ease';
}

/**
 * Hide combo counter
 */
function hideComboCounter() {
    const counter = document.querySelector('.combo-counter');
    if (counter) {
        counter.remove();
    }
}

/**
 * Calculate bonus XP from combo
 */
function getComboBonus(baseXP) {
    const multiplier = 1 + (GameState.combo * 0.1);
    return Math.round(baseXP * multiplier) - baseXP;
}

// ==========================================
// DAILY REWARDS
// ==========================================

/**
 * Check and show daily reward if applicable
 */
function checkDailyReward() {
    const lastClaim = localStorage.getItem('lastDailyReward');
    const today = new Date().toDateString();

    if (lastClaim !== today) {
        showDailyRewardModal();
    }
}

/**
 * Show daily reward modal
 */
function showDailyRewardModal() {
    const modal = document.createElement('div');
    modal.className = 'daily-reward-modal';
    modal.innerHTML = `
        <div class="daily-reward-content">
            <div class="daily-reward-title">🎁 Daily Reward!</div>
            <div class="daily-reward-subtitle">Tap the chest to claim your reward</div>
            <div class="reward-chest" onclick="openDailyReward(this)">📦</div>
            <div class="reward-reveal">
                <div class="reward-points" id="rewardPoints"></div>
                <p>Bonus XP added to your account!</p>
                <button class="btn btn-primary" onclick="closeDailyReward()">Awesome!</button>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
}

/**
 * Open daily reward chest
 */
function openDailyReward(chest) {
    chest.textContent = '🎉';
    chest.classList.add('opened');

    // Random reward between 10-50 XP
    const reward = Math.floor(Math.random() * 41) + 10;

    setTimeout(() => {
        chest.style.display = 'none';
        const reveal = document.querySelector('.reward-reveal');
        document.getElementById('rewardPoints').textContent = `+${reward} XP`;
        reveal.classList.add('visible');

        createConfetti(30);
        playSound('achievement');

        // Save claim date
        localStorage.setItem('lastDailyReward', new Date().toDateString());
    }, 500);
}

/**
 * Close daily reward modal
 */
function closeDailyReward() {
    const modal = document.querySelector('.daily-reward-modal');
    if (modal) {
        modal.style.animation = 'fadeIn 0.3s ease reverse';
        setTimeout(() => modal.remove(), 300);
    }
}

// ==========================================
// STREAK DISPLAY
// ==========================================

/**
 * Create animated streak display
 */
function createStreakDisplay(streak) {
    if (streak < 2) return '';

    let fireCount = Math.min(streak, 5);
    let fires = '🔥'.repeat(fireCount);

    return `
        <div class="streak-fire">
            <span class="streak-count">${streak}</span>
            <span class="streak-text">day streak ${fires}</span>
        </div>
    `;
}

// ==========================================
// XP PROGRESS BAR
// ==========================================

/**
 * Create XP progress bar for level
 */
function createXPBar(currentXP, requiredXP) {
    const percentage = Math.min((currentXP / requiredXP) * 100, 100);

    return `
        <div class="xp-bar-container">
            <div class="xp-bar-fill" style="width: ${percentage}%"></div>
        </div>
        <div class="xp-bar-label">
            <span>${currentXP} / ${requiredXP} XP</span>
            <span>Level ${Math.floor(currentXP / 100) + 1}</span>
        </div>
    `;
}

/**
 * Animate XP bar fill
 */
function animateXPGain(element, oldXP, newXP, maxXP) {
    const bar = element.querySelector('.xp-bar-fill');
    if (!bar) return;

    // Animate from old to new
    bar.style.transition = 'none';
    bar.style.width = `${(oldXP / maxXP) * 100}%`;

    requestAnimationFrame(() => {
        bar.style.transition = 'width 1s ease';
        bar.style.width = `${(newXP / maxXP) * 100}%`;
    });
}

// ==========================================
// STAR BURST EFFECT
// ==========================================

/**
 * Create star burst effect at position
 */
function createStarBurst(x, y) {
    const burst = document.createElement('div');
    burst.className = 'star-burst';
    burst.style.left = `${x}px`;
    burst.style.top = `${y}px`;

    const stars = ['⭐', '✨', '💫', '🌟'];

    for (let i = 0; i < 8; i++) {
        const star = document.createElement('span');
        star.textContent = stars[Math.floor(Math.random() * stars.length)];
        const angle = (i / 8) * Math.PI * 2;
        const distance = 50 + Math.random() * 50;
        star.style.setProperty('--tx', `${Math.cos(angle) * distance}px`);
        star.style.setProperty('--ty', `${Math.sin(angle) * distance}px`);
        burst.appendChild(star);
    }

    document.body.appendChild(burst);
    setTimeout(() => burst.remove(), 800);
}

// ==========================================
// SHAKE & FEEDBACK EFFECTS
// ==========================================

/**
 * Shake element for wrong answer
 */
function shakeElement(element) {
    element.classList.add('shake');
    playSound('error');
    setTimeout(() => element.classList.remove('shake'), 500);
}

/**
 * Pulse element for correct answer
 */
function pulseSuccess(element) {
    element.classList.add('pulse-success');
    setTimeout(() => element.classList.remove('pulse-success'), 500);
}

// ==========================================
// INTEGRATION WITH MAIN APP
// ==========================================

/**
 * Handle successful challenge completion
 */
function handleChallengeSuccess(points, isNewBadge = null, isLevelUp = false, newLevel = 0) {
    // Increment combo
    incrementCombo();

    // Calculate bonus from combo
    const comboBonus = getComboBonus(points);
    const totalPoints = points + comboBonus;

    // Show XP popup
    const bonusText = comboBonus > 0 ? `(+${comboBonus} combo bonus!)` : '';
    showXPPopup(totalPoints, bonusText);

    // Create particle effects
    createConfetti(30);

    // Check for level up
    if (isLevelUp) {
        setTimeout(() => showLevelUp(newLevel), 1000);
    }

    // Check for new badge
    if (isNewBadge) {
        setTimeout(() => showAchievementUnlock(isNewBadge), isLevelUp ? 5000 : 1000);
    }

    return totalPoints;
}

/**
 * Handle failed challenge attempt
 */
function handleChallengeFail(feedbackElement) {
    resetCombo();
    shakeElement(feedbackElement);
}

// ==========================================
// GLOBAL EXPORTS
// ==========================================

window.GameEffects = {
    showXPPopup,
    showLevelUp,
    showAchievementUnlock,
    createConfetti,
    createParticles,
    createStarBurst,
    incrementCombo,
    resetCombo,
    getComboBonus,
    checkDailyReward,
    shakeElement,
    pulseSuccess,
    createXPBar,
    animateXPGain,
    handleChallengeSuccess,
    handleChallengeFail,
    playSound,
    GameState
};

// Check for daily reward on page load
document.addEventListener('DOMContentLoaded', () => {
    const token = localStorage.getItem('databricks_token');
    if (token) {
        setTimeout(checkDailyReward, 1000);
    }
});
