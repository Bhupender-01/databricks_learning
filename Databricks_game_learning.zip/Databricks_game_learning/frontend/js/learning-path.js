/**
 * Duolingo-Style Learning Path
 * Progressive skill tree with crowns and lessons
 */

// ==========================================
// LEARNING DATA STRUCTURE
// ==========================================

const learningUnits = [
    {
        id: 1,
        name: "SQL Foundations",
        icon: "📊",
        description: "Master the basics of SQL queries",
        skills: [
            {
                id: "select-basics",
                name: "SELECT Basics",
                icon: "📋",
                description: "Learn to retrieve data from tables",
                crowns: 0,
                maxCrowns: 5,
                lessons: [
                    { id: 1, title: "What is SELECT?", type: "Learn", xp: 10, completed: true },
                    { id: 2, title: "SELECT all columns", type: "Practice", xp: 15, completed: true },
                    { id: 3, title: "SELECT specific columns", type: "Practice", xp: 15, completed: false },
                    { id: 4, title: "Column aliases", type: "Learn", xp: 10, completed: false },
                    { id: 5, title: "Challenge: Build a query", type: "Challenge", xp: 25, completed: false }
                ],
                unlocked: true
            },
            {
                id: "where-clause",
                name: "WHERE Filters",
                icon: "🔍",
                description: "Filter data with conditions",
                crowns: 0,
                maxCrowns: 5,
                lessons: [
                    { id: 1, title: "Introduction to WHERE", type: "Learn", xp: 10, completed: false },
                    { id: 2, title: "Comparison operators", type: "Practice", xp: 15, completed: false },
                    { id: 3, title: "AND & OR conditions", type: "Practice", xp: 15, completed: false },
                    { id: 4, title: "IN and BETWEEN", type: "Learn", xp: 10, completed: false },
                    { id: 5, title: "Challenge: Complex filters", type: "Challenge", xp: 25, completed: false }
                ],
                unlocked: true
            },
            {
                id: "order-sort",
                name: "Sorting Results",
                icon: "↕️",
                description: "Order your query results",
                crowns: 0,
                maxCrowns: 5,
                lessons: [
                    { id: 1, title: "ORDER BY basics", type: "Learn", xp: 10, completed: false },
                    { id: 2, title: "ASC vs DESC", type: "Practice", xp: 15, completed: false },
                    { id: 3, title: "Multiple columns", type: "Practice", xp: 15, completed: false },
                    { id: 4, title: "NULL handling", type: "Learn", xp: 10, completed: false },
                    { id: 5, title: "Challenge: Sort mastery", type: "Challenge", xp: 25, completed: false }
                ],
                unlocked: false
            }
        ],
        checkpoint: {
            name: "SQL Basics Test",
            description: "Prove your SQL basics knowledge!",
            unlocked: false,
            completed: false,
            reward: 100
        }
    },
    {
        id: 2,
        name: "SQL Aggregations",
        icon: "📈",
        description: "Group and summarize data",
        skills: [
            {
                id: "group-by",
                name: "GROUP BY",
                icon: "📊",
                description: "Group rows for calculations",
                crowns: 0,
                maxCrowns: 5,
                lessons: [
                    { id: 1, title: "What is GROUP BY?", type: "Learn", xp: 10, completed: false },
                    { id: 2, title: "COUNT function", type: "Practice", xp: 15, completed: false },
                    { id: 3, title: "SUM and AVG", type: "Practice", xp: 15, completed: false },
                    { id: 4, title: "Multiple groups", type: "Learn", xp: 10, completed: false },
                    { id: 5, title: "Challenge: Sales report", type: "Challenge", xp: 25, completed: false }
                ],
                unlocked: false
            },
            {
                id: "having",
                name: "HAVING Clause",
                icon: "🎯",
                description: "Filter grouped results",
                crowns: 0,
                maxCrowns: 5,
                lessons: [
                    { id: 1, title: "HAVING vs WHERE", type: "Learn", xp: 10, completed: false },
                    { id: 2, title: "Filter aggregates", type: "Practice", xp: 15, completed: false },
                    { id: 3, title: "Complex conditions", type: "Practice", xp: 15, completed: false },
                    { id: 4, title: "Best practices", type: "Learn", xp: 10, completed: false },
                    { id: 5, title: "Challenge: Top performers", type: "Challenge", xp: 25, completed: false }
                ],
                unlocked: false
            },
            {
                id: "aggregate-funcs",
                name: "Aggregate Functions",
                icon: "🔢",
                description: "Master all aggregate functions",
                crowns: 0,
                maxCrowns: 5,
                lessons: [
                    { id: 1, title: "MIN and MAX", type: "Learn", xp: 10, completed: false },
                    { id: 2, title: "DISTINCT counts", type: "Practice", xp: 15, completed: false },
                    { id: 3, title: "Nested aggregates", type: "Practice", xp: 15, completed: false },
                    { id: 4, title: "NULL handling", type: "Learn", xp: 10, completed: false },
                    { id: 5, title: "Challenge: Statistics", type: "Challenge", xp: 25, completed: false }
                ],
                unlocked: false
            }
        ],
        checkpoint: {
            name: "Aggregation Master",
            description: "Test your aggregation skills!",
            unlocked: false,
            completed: false,
            reward: 150
        }
    },
    {
        id: 3,
        name: "SQL Joins",
        icon: "🔗",
        description: "Combine data from multiple tables",
        skills: [
            {
                id: "inner-join",
                name: "INNER JOIN",
                icon: "⭕",
                description: "Match rows from two tables",
                crowns: 0,
                maxCrowns: 5,
                lessons: [
                    { id: 1, title: "What is a JOIN?", type: "Learn", xp: 10, completed: false },
                    { id: 2, title: "INNER JOIN syntax", type: "Practice", xp: 15, completed: false },
                    { id: 3, title: "JOIN conditions", type: "Practice", xp: 15, completed: false },
                    { id: 4, title: "Table aliases", type: "Learn", xp: 10, completed: false },
                    { id: 5, title: "Challenge: Customer orders", type: "Challenge", xp: 25, completed: false }
                ],
                unlocked: false
            },
            {
                id: "left-join",
                name: "LEFT JOIN",
                icon: "⬅️",
                description: "Keep all left table rows",
                crowns: 0,
                maxCrowns: 5,
                lessons: [
                    { id: 1, title: "LEFT vs INNER", type: "Learn", xp: 10, completed: false },
                    { id: 2, title: "Handling NULLs", type: "Practice", xp: 15, completed: false },
                    { id: 3, title: "Anti-joins", type: "Practice", xp: 15, completed: false },
                    { id: 4, title: "Multiple joins", type: "Learn", xp: 10, completed: false },
                    { id: 5, title: "Challenge: Find missing", type: "Challenge", xp: 25, completed: false }
                ],
                unlocked: false
            },
            {
                id: "advanced-joins",
                name: "Advanced Joins",
                icon: "🔀",
                description: "FULL, CROSS, and SELF joins",
                crowns: 0,
                maxCrowns: 5,
                lessons: [
                    { id: 1, title: "FULL OUTER JOIN", type: "Learn", xp: 10, completed: false },
                    { id: 2, title: "CROSS JOIN", type: "Practice", xp: 15, completed: false },
                    { id: 3, title: "Self-referencing", type: "Practice", xp: 15, completed: false },
                    { id: 4, title: "Join strategies", type: "Learn", xp: 10, completed: false },
                    { id: 5, title: "Challenge: Complex joins", type: "Challenge", xp: 25, completed: false }
                ],
                unlocked: false
            }
        ],
        checkpoint: {
            name: "Join Expert",
            description: "Master all join types!",
            unlocked: false,
            completed: false,
            reward: 200
        }
    },
    {
        id: 4,
        name: "PySpark Basics",
        icon: "🐍",
        description: "DataFrames and transformations",
        skills: [
            {
                id: "dataframes",
                name: "DataFrames",
                icon: "📑",
                description: "Create and explore DataFrames",
                crowns: 0,
                maxCrowns: 5,
                lessons: [
                    { id: 1, title: "What is a DataFrame?", type: "Learn", xp: 10, completed: false },
                    { id: 2, title: "Creating DataFrames", type: "Practice", xp: 15, completed: false },
                    { id: 3, title: "Schema and types", type: "Practice", xp: 15, completed: false },
                    { id: 4, title: "show() and display()", type: "Learn", xp: 10, completed: false },
                    { id: 5, title: "Challenge: Load data", type: "Challenge", xp: 25, completed: false }
                ],
                unlocked: false
            },
            {
                id: "transformations",
                name: "Transformations",
                icon: "🔄",
                description: "Select, filter, and transform",
                crowns: 0,
                maxCrowns: 5,
                lessons: [
                    { id: 1, title: "select() method", type: "Learn", xp: 10, completed: false },
                    { id: 2, title: "filter() and where()", type: "Practice", xp: 15, completed: false },
                    { id: 3, title: "withColumn()", type: "Practice", xp: 15, completed: false },
                    { id: 4, title: "drop() and rename()", type: "Learn", xp: 10, completed: false },
                    { id: 5, title: "Challenge: Transform data", type: "Challenge", xp: 25, completed: false }
                ],
                unlocked: false
            },
            {
                id: "pyspark-agg",
                name: "PySpark Aggregations",
                icon: "📊",
                description: "GroupBy and aggregations",
                crowns: 0,
                maxCrowns: 5,
                lessons: [
                    { id: 1, title: "groupBy() basics", type: "Learn", xp: 10, completed: false },
                    { id: 2, title: "agg() function", type: "Practice", xp: 15, completed: false },
                    { id: 3, title: "Multiple aggregates", type: "Practice", xp: 15, completed: false },
                    { id: 4, title: "Window functions", type: "Learn", xp: 10, completed: false },
                    { id: 5, title: "Challenge: Analytics", type: "Challenge", xp: 25, completed: false }
                ],
                unlocked: false
            }
        ],
        checkpoint: {
            name: "PySpark Developer",
            description: "Prove your PySpark skills!",
            unlocked: false,
            completed: false,
            reward: 250
        }
    },
    {
        id: 5,
        name: "Delta Lake",
        icon: "🌊",
        description: "ACID transactions and time travel",
        skills: [
            {
                id: "delta-basics",
                name: "Delta Basics",
                icon: "📦",
                description: "Read and write Delta tables",
                crowns: 0,
                maxCrowns: 5,
                lessons: [
                    { id: 1, title: "What is Delta Lake?", type: "Learn", xp: 10, completed: false },
                    { id: 2, title: "Reading Delta", type: "Practice", xp: 15, completed: false },
                    { id: 3, title: "Writing Delta", type: "Practice", xp: 15, completed: false },
                    { id: 4, title: "ACID transactions", type: "Learn", xp: 10, completed: false },
                    { id: 5, title: "Challenge: ETL pipeline", type: "Challenge", xp: 25, completed: false }
                ],
                unlocked: false
            },
            {
                id: "time-travel",
                name: "Time Travel",
                icon: "⏰",
                description: "Query historical data",
                crowns: 0,
                maxCrowns: 5,
                lessons: [
                    { id: 1, title: "Version history", type: "Learn", xp: 10, completed: false },
                    { id: 2, title: "versionAsOf", type: "Practice", xp: 15, completed: false },
                    { id: 3, title: "timestampAsOf", type: "Practice", xp: 15, completed: false },
                    { id: 4, title: "Restore versions", type: "Learn", xp: 10, completed: false },
                    { id: 5, title: "Challenge: Audit trail", type: "Challenge", xp: 25, completed: false }
                ],
                unlocked: false
            },
            {
                id: "delta-advanced",
                name: "Advanced Delta",
                icon: "🚀",
                description: "MERGE, OPTIMIZE, and more",
                crowns: 0,
                maxCrowns: 5,
                lessons: [
                    { id: 1, title: "MERGE INTO", type: "Learn", xp: 10, completed: false },
                    { id: 2, title: "OPTIMIZE", type: "Practice", xp: 15, completed: false },
                    { id: 3, title: "Z-ORDER", type: "Practice", xp: 15, completed: false },
                    { id: 4, title: "VACUUM", type: "Learn", xp: 10, completed: false },
                    { id: 5, title: "Challenge: Production table", type: "Challenge", xp: 25, completed: false }
                ],
                unlocked: false
            }
        ],
        checkpoint: {
            name: "Delta Lake Expert",
            description: "Master Delta Lake!",
            unlocked: false,
            completed: false,
            reward: 300
        }
    }
];

// ==========================================
// USER PROGRESS STATE
// ==========================================

let userProgress = {
    currentUnit: 1,
    totalXP: 350,
    level: 1,
    streak: 5,
    gems: 250,
    hearts: 5,
    dailyXP: 30,
    dailyGoal: 100,
    powerUps: {
        freeze: 2,
        double: 1,
        heart: 3
    },
    completedLessons: ['select-basics-1', 'select-basics-2'],
    skillProgress: {}
};

// ==========================================
// INITIALIZATION
// ==========================================

function initLearningPath() {
    loadProgress();
    // Render full path
    renderSkillTree();
    updateUI();

    // Auto-scroll to current unit if possible
    setTimeout(() => {
        const currentId = userProgress.currentUnit || 1;
        const currentEl = document.getElementById(`unit-${currentId}`);
        if (currentEl) {
            currentEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }, 500);
}

function loadProgress() {
    const saved = localStorage.getItem('learningProgress');
    if (saved) {
        const parsed = JSON.parse(saved);
        userProgress = { ...userProgress, ...parsed };

        // Restore learning units state if exists
        if (parsed.unitsState) {
            restoreUnitsState(parsed.unitsState);
        }
    }
}

function saveProgress() {
    // Save current state of learning units
    userProgress.unitsState = captureUnitsState();
    localStorage.setItem('learningProgress', JSON.stringify(userProgress));
}

function captureUnitsState() {
    return learningUnits.map(unit => ({
        id: unit.id,
        skills: unit.skills.map(skill => ({
            id: skill.id,
            crowns: skill.crowns,
            unlocked: skill.unlocked,
            lessons: skill.lessons.map(l => ({ id: l.id, completed: l.completed }))
        })),
        checkpoint: {
            unlocked: unit.checkpoint.unlocked,
            completed: unit.checkpoint.completed
        }
    }));
}

function restoreUnitsState(savedUnits) {
    savedUnits.forEach(savedUnit => {
        const realUnit = learningUnits.find(u => u.id === savedUnit.id);
        if (realUnit) {
            if (savedUnit.checkpoint) Object.assign(realUnit.checkpoint, savedUnit.checkpoint);

            savedUnit.skills.forEach(savedSkill => {
                const realSkill = realUnit.skills.find(s => s.id === savedSkill.id);
                if (realSkill) {
                    realSkill.crowns = savedSkill.crowns;
                    realSkill.unlocked = savedSkill.unlocked;

                    savedSkill.lessons.forEach(savedLesson => {
                        const realLesson = realSkill.lessons.find(l => l.id === savedLesson.id);
                        if (realLesson) realLesson.completed = savedLesson.completed;
                    });
                }
            });
        }
    });
}

// ==========================================
// RENDERING
// ==========================================

// Removed renderUnitsSidebar as sidebar is gone

function renderSkillTree() {
    const container = document.getElementById('skillTree');
    if (!container) return;

    let html = '';

    // Loop through ALL units to capture full path
    learningUnits.forEach((unit, unitIndex) => {
        // Render Unit Header within the path
        html += `
            <div class="path-unit-header ${unitIndex > 0 ? 'mt-unit' : ''}" id="unit-${unit.id}">
                <div class="unit-header-content">
                    <div class="unit-title-row">
                        <h2 class="unit-title">Unit ${unit.id}: ${unit.name}</h2>
                        <span class="unit-desc">${unit.description}</span>
                    </div>
                </div>
            </div>
            <div class="unit-skills-container">
        `;

        unit.skills.forEach((skill, index) => {
            const offsetClass = index % 3 === 1 ? 'offset-left' : (index % 3 === 2 ? 'offset-right' : '');
            const statusClass = skill.unlocked
                ? (skill.crowns >= 1 ? 'completed' : 'current')
                : 'locked';

            html += `
                <div class="skill-row ${offsetClass}">
                    <div class="skill-node ${statusClass}" onclick="${skill.unlocked ? `openSkill('${skill.id}')` : ''}" title="${skill.name}">
                        <div class="skill-icon">${skill.icon}</div>
                        <div class="skill-crowns-mini">
                            ${[1, 2, 3, 4, 5].map(i => `<div class="crown-mini ${skill.crowns >= i ? 'earned' : ''}"></div>`).join('')}
                        </div>
                        <div class="skill-label">${skill.name}</div>
                    </div>
                </div>
            `;
        });

        // Add Checkpoint if exists
        if (unit.checkpoint) {
            html += `
                <div class="skill-row">
                    <div class="checkpoint-node ${unit.checkpoint.unlocked ? (unit.checkpoint.completed ? 'completed' : 'current') : 'locked'}"
                         onclick="${unit.checkpoint.unlocked ? 'startCheckpoint()' : ''}">
                        <div class="checkpoint-icon">🏆</div>
                        <div class="skill-label">${unit.checkpoint.name}</div>
                    </div>
                </div>
            `;
        }

        html += `</div>`; // Close unit-skills-container
    });

    container.innerHTML = html;
}

function renderSkillTree(unitId) {
    const unit = learningUnits.find(u => u.id === unitId);
    if (!unit) return;

    // Update header
    document.getElementById('currentUnitTitle').textContent = `Unit ${unit.id}: ${unit.name}`;
    document.getElementById('currentUnitDesc').textContent = unit.description;

    const container = document.getElementById('skillTree');
    if (!container) return;

    let html = '';

    unit.skills.forEach((skill, index) => {
        const offsetClass = index % 3 === 1 ? 'offset-left' : (index % 3 === 2 ? 'offset-right' : '');
        const statusClass = skill.unlocked
            ? (skill.crowns >= 1 ? 'completed' : 'current')
            : 'locked';

        const completedLessons = skill.lessons.filter(l => l.completed).length;

        html += `
            <div class="skill-row ${offsetClass}">
                <div class="skill-node ${statusClass}" onclick="${skill.unlocked ? `openSkill('${skill.id}')` : ''}">
                    <div class="skill-icon">${skill.icon}</div>
                    <div class="skill-crowns-mini">
                        ${[1, 2, 3, 4, 5].map(i => `<div class="crown-mini ${skill.crowns >= i ? 'earned' : ''}"></div>`).join('')}
                    </div>
                    <div class="skill-label">${skill.name}</div>
                </div>
            </div>
        `;
    });

    // Add checkpoint
    html += `
        <div class="checkpoint ${unit.checkpoint.unlocked ? '' : 'locked'}">
            <div class="checkpoint-icon">🏆</div>
            <h3>${unit.checkpoint.name}</h3>
            <p>${unit.checkpoint.description}</p>
            ${unit.checkpoint.unlocked ? '<button class="btn btn-primary" onclick="startCheckpoint()">Take Test (+' + unit.checkpoint.reward + ' XP)</button>' : '<p>Complete all skills to unlock!</p>'}
        </div>
    `;

    container.innerHTML = html;
}

function updateUI() {
    // Update progress ring
    const progressRing = document.querySelector('.progress-ring circle.progress');
    if (progressRing) {
        const totalSkills = learningUnits.reduce((sum, u) => sum + u.skills.length, 0);
        const completedSkills = learningUnits.reduce((sum, u) =>
            sum + u.skills.filter(s => s.crowns >= 1).length, 0);
        const percent = Math.round((completedSkills / totalSkills) * 100);
        const offset = 283 - (283 * percent / 100);
        progressRing.style.strokeDashoffset = offset;
        document.getElementById('progressPercent').textContent = percent + '%';
    }

    // Update daily goal
    const dailyFill = document.getElementById('dailyGoalFill');
    if (dailyFill) {
        dailyFill.style.width = `${(userProgress.dailyXP / userProgress.dailyGoal) * 100}%`;
    }
    const dailyXP = document.getElementById('dailyXP');
    if (dailyXP) dailyXP.textContent = userProgress.dailyXP;

    // Update nav badges
    const streak = document.getElementById('streakCount');
    const gems = document.getElementById('gemsCount');
    const hearts = document.getElementById('heartsCount');
    if (streak) streak.textContent = userProgress.streak;
    if (gems) gems.textContent = userProgress.gems;
    if (hearts) hearts.textContent = userProgress.hearts;

    // Update power-up counts
    const freeze = document.getElementById('freezeCount');
    const double = document.getElementById('doubleCount');
    const heart = document.getElementById('heartCount');
    if (freeze) freeze.textContent = userProgress.powerUps.freeze;
    if (double) double.textContent = userProgress.powerUps.double;
    if (heart) heart.textContent = userProgress.powerUps.heart;
}

// ==========================================
// SKILL MODAL
// ==========================================

let currentSkill = null;

function openSkill(skillId) {
    const unit = learningUnits.find(u => u.skills.some(s => s.id === skillId));
    const skill = unit?.skills.find(s => s.id === skillId);
    if (!skill) return;

    currentSkill = skill;

    document.getElementById('modalIcon').textContent = skill.icon;
    document.getElementById('modalTitle').textContent = skill.name;
    document.getElementById('modalDesc').textContent = skill.description;

    // Render crowns
    const crownsContainer = document.getElementById('modalCrowns');
    crownsContainer.innerHTML = [1, 2, 3, 4, 5].map(i => `
        <div class="crown ${skill.crowns >= i ? 'earned' : ''} ${i === 5 ? 'legendary' : ''}">👑</div>
    `).join('');

    // Render progress
    const completedLessons = skill.lessons.filter(l => l.completed).length;
    document.getElementById('modalProgress').textContent =
        `Level ${skill.crowns + 1} of 5 • ${completedLessons}/${skill.lessons.length} lessons completed`;

    // Render lessons
    const lessonList = document.getElementById('lessonList');
    lessonList.innerHTML = skill.lessons.map((lesson, i) => {
        const isLocked = i > 0 && !skill.lessons[i - 1].completed;
        return `
            <div class="lesson-item ${lesson.completed ? 'completed' : ''} ${isLocked ? 'locked' : ''}"
                 onclick="${!isLocked ? `selectLesson(${i})` : ''}">
                <div class="lesson-status">${lesson.completed ? '✓' : (i + 1)}</div>
                <div class="lesson-info">
                    <div class="lesson-title">${lesson.title}</div>
                    <div class="lesson-type">${lesson.type}</div>
                </div>
                <div class="lesson-xp">+${lesson.xp} XP</div>
            </div>
        `;
    }).join('');

    // Update button
    const nextLesson = skill.lessons.find(l => !l.completed);
    document.getElementById('startLessonBtn').textContent =
        nextLesson ? `Start: ${nextLesson.title}` : 'Practice Again';

    document.getElementById('skillModal').classList.add('active');
}

function closeSkillModal() {
    document.getElementById('skillModal').classList.remove('active');
    currentSkill = null;
}

// ==========================================
// LESSONS
// ==========================================

let currentLessonIndex = 0;

function selectLesson(index) {
    currentLessonIndex = index;
    const btn = document.getElementById('startLessonBtn');
    btn.textContent = `Start: ${currentSkill.lessons[index].title}`;
}

function startLesson() {
    if (!currentSkill) return;

    const lesson = currentSkill.lessons[currentLessonIndex] || currentSkill.lessons.find(l => !l.completed);
    if (!lesson) return;

    // Save skill reference BEFORE closing modal (which sets currentSkill to null)
    const skillForLesson = currentSkill;
    const skillIcon = currentSkill.icon;

    // Close skill modal but DON'T null the reference yet
    document.getElementById('skillModal').classList.remove('active');

    // Load lesson content
    const lessonModal = document.getElementById('lessonModal');
    const lessonContent = document.getElementById('lessonContent');

    lessonContent.innerHTML = `
        <div class="lesson-header">
            <button class="btn btn-ghost" onclick="closeLessonModal()">✕ Exit</button>
            <div class="lesson-progress-bar">
                <div class="lesson-progress-fill" id="lessonProgressFill" style="width: 0%"></div>
            </div>
            <div class="lesson-hearts">❤️ ${userProgress.hearts}</div>
        </div>
        
        <div class="lesson-body" id="lessonBody">
            <div class="lesson-intro">
                <div class="lesson-icon">${skillIcon}</div>
                <h1>${lesson.title}</h1>
                <p>${lesson.type} Lesson</p>
                <button class="btn btn-primary btn-large" onclick="startLessonContent()">Let's Go!</button>
            </div>
        </div>
    `;

    lessonModal.classList.add('active');
}

function startLessonContent() {
    const lessonBody = document.getElementById('lessonBody');

    // Simulate lesson content - in real app, this would load actual content
    lessonBody.innerHTML = `
        <div class="lesson-question">
            <h2>What does SELECT * return?</h2>
            <div class="lesson-options">
                <div class="lesson-option" onclick="checkAnswer(this, true)">
                    <span>All columns from the table</span>
                </div>
                <div class="lesson-option" onclick="checkAnswer(this, false)">
                    <span>Only the first column</span>
                </div>
                <div class="lesson-option" onclick="checkAnswer(this, false)">
                    <span>No columns</span>
                </div>
                <div class="lesson-option" onclick="checkAnswer(this, false)">
                    <span>An error</span>
                </div>
            </div>
        </div>
    `;

    document.getElementById('lessonProgressFill').style.width = '20%';
}

function checkAnswer(element, isCorrect) {
    const options = document.querySelectorAll('.lesson-option');
    options.forEach(opt => opt.style.pointerEvents = 'none');

    if (isCorrect) {
        element.classList.add('correct');
        userProgress.dailyXP += 5;
        updateUI();

        setTimeout(() => completeLesson(), 1500);
    } else {
        element.classList.add('wrong');
        userProgress.hearts--;
        updateUI();

        if (userProgress.hearts <= 0) {
            setTimeout(() => {
                alert('No hearts left! Take a break or use a power-up.');
                closeLessonModal();
            }, 1000);
        }
    }
}

function completeLesson() {
    if (!currentSkill) return;

    const lesson = currentSkill.lessons[currentLessonIndex];
    if (lesson) {
        lesson.completed = true;
        userProgress.totalXP += lesson.xp;
        userProgress.dailyXP += lesson.xp;
        userProgress.gems += 5;

        // Check if all lessons completed -> earn crown
        const allCompleted = currentSkill.lessons.every(l => l.completed);
        if (allCompleted && currentSkill.crowns < 5) {
            currentSkill.crowns++;
            // Reset lessons for next crown level (harder)
            if (currentSkill.crowns < 5) {
                currentSkill.lessons.forEach(l => l.completed = false);
            }
        }

        saveProgress();
        updateUI();
    }

    const lessonBody = document.getElementById('lessonBody');
    lessonBody.innerHTML = `
        <div class="lesson-complete">
            <div class="complete-icon">🎉</div>
            <h1>Lesson Complete!</h1>
            <div class="rewards-earned">
                <div class="reward">+${lesson?.xp || 10} XP</div>
                <div class="reward">+5 💎</div>
            </div>
            <button class="btn btn-primary btn-large" onclick="closeLessonModal()">Continue</button>
        </div>
    `;

    document.getElementById('lessonProgressFill').style.width = '100%';
}

function closeLessonModal() {
    document.getElementById('lessonModal').classList.remove('active');
    renderSkillTree();
    // renderUnitsSidebar() removed
}

// ==========================================
// NAVIGATION
// ==========================================

// selectUnit removed as we show full path now

function startCheckpoint() {
    // Navigate to games page for checkpoint test
    window.location.href = 'games.html';
}

function usePowerUp(type) {
    switch (type) {
        case 'streak-freeze':
            if (userProgress.powerUps.freeze > 0) {
                userProgress.powerUps.freeze--;
                showToast('Streak freeze activated!', 'success');
            }
            break;
        case 'double-xp':
            if (userProgress.powerUps.double > 0) {
                userProgress.powerUps.double--;
                showToast('2X XP active for next lesson!', 'success');
            }
            break;
        case 'heart':
            if (userProgress.powerUps.heart > 0 && userProgress.hearts < 5) {
                userProgress.powerUps.heart--;
                userProgress.hearts++;
                showToast('+1 Heart!', 'success');
            }
            break;
    }
    saveProgress();
    updateUI();
}

function showToast(message, type) {
    if (window.GameEffects) {
        GameEffects.showToast?.(message, type);
    } else {
        alert(message);
    }
}

// Make functions global
window.initLearningPath = initLearningPath;
window.selectUnit = selectUnit;
window.openSkill = openSkill;
window.closeSkillModal = closeSkillModal;
window.selectLesson = selectLesson;
window.startLesson = startLesson;
window.startLessonContent = startLessonContent;
window.checkAnswer = checkAnswer;
window.closeLessonModal = closeLessonModal;
window.startCheckpoint = startCheckpoint;
window.usePowerUp = usePowerUp;

// Initialize on load
document.addEventListener('DOMContentLoaded', initLearningPath);
